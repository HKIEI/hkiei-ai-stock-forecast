# AI 股市走勢預測_HKIEI

以 Yahoo Finance 已收市日線在本機推算股價及指數走勢。支援港股、美股、指數、ETF 及加密貨幣。輸出包括整體及每日方向、悲觀／中間／樂觀三種收市情境、SVG 走勢圖、互動 HTML 報告及歷史回測。預設模擬 50 次，涵蓋 10 個交易日。

## 安裝

需要 Apple Silicon Mac、Python 3.9 或以上、網絡連線及可用磁碟空間。從插件列表安裝 **AI 股市走勢預測_HKIEI**，再開新對話使用。手動安裝時，可將解壓後的 `skills/hkiei-market-forecast` 放進本機技能資料夾。Claude Code 的技能資料夾為 `~/.claude/skills/`。

在技能資料夾執行以下指令檢查環境。若尚未安裝，省略 `--check` 完成一次性設定。設定會在獨立環境下載 PyTorch、模型及分詞器。新安裝的預設環境為 `~/.cache/hkiei-market-forecast/`，亦可設定 `HKIEI_FORECAST_HOME`。相容的現有安裝可以繼續使用。

```sh
python3 setup_market_forecast.py --check
```

## 使用

- 「預估恒指未來 5 個香港交易日走勢，列出每日方向及三種收市情境，附互動圖表及 SVG。」
- 「模擬騰訊未來 5 個交易日的走勢，輸出 1080 × 1920 直度圖。」
- 「回測 NVDA，列出落入模擬範圍的次數及與假設股價不變相比的誤差。」

以終端機執行恒指例子時，先切換到技能資料夾。

```sh
python3 market_forecast.py '^HSI' --days 5 --json hsi_forecast.json --save-raw hsi_history.json --svg hsi_forecast.svg
python3 market_report.py --forecast hsi_forecast.json --raw hsi_history.json -o hsi_forecast.html
```

## 報告及資料限制

報告列出所用行情期間、最新收市價及三種收市情境。每日方向按中間情境計算，首日與最新實際收市相比，其後與上一日的中間情境相比。模型只參考歷史行情。業績、議息及其他事件須另行核對，實際價格可能超出模擬範圍。資料可能有延遲或錯誤。模擬結果只供教育及資訊參考，並不構成投資建議。歷史表現不代表未來。

## 移除

在技能資料夾執行 `python3 setup_market_forecast.py --remove`，再移除插件或技能。

## 第三方元件及授權

模型程式碼、來源記錄及 MIT 授權載於 `skills/hkiei-market-forecast/vendor/`。模型權重及分詞器於安裝時下載。隨附的投創教育標誌只供此插件的報告使用。各套件依原授權使用。

## 版權

版權所有 © 2026 投創教育。保留所有權利（上述第三方元件除外）。

未經投創教育書面同意，不得修改、複製、轉售或再分發本 skill 或其任何部分（上述第三方元件按其原有授權處理）。
