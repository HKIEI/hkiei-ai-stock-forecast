#!/usr/bin/env python3
"""Build a shareable one-file HTML report from market_forecast.py outputs. Standard library only.

  python3 market_report.py --forecast 1211_forecast.json --raw 1211_yahoo_raw.json \
      [--backtest 1211_backtest.json] [--events "期內事件說明"] [--logo logo.png | --no-logo] -o report.html

--forecast and --raw come from one run (`--json FILE --save-raw FILE`); --backtest from a `--backtest --json FILE` run.
"""
import argparse
import base64
import datetime as dt
import html
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import market_forecast as kf  # noqa: E402

HISTORY_DAYS = 40
DEFAULT_LOGO = HERE / "assets" / "hkiei-logo.png"
E = html.escape


def history(forecast, raw):
    """Re-parse the saved Yahoo payload as of the forecast run, so the history matches the bars used."""
    now = dt.datetime.fromisoformat(forecast["generated_utc"]).timestamp()
    bars = kf.parse_chart(raw, now)[2]
    end = forecast["data_source"]["history"]["end"]
    bars = [b for b in bars if b["date"] <= end]
    if not bars or bars[-1]["date"] != end:
        raise ValueError("原始行情與模擬結果不符，請使用同一次執行保存的 --save-raw 檔案。")
    return [{"date": b["date"], "close": b["close"]} for b in bars[-HISTORY_DAYS:]]


def tile(label, value, note="", tone=""):
    return ('<div class="tile %s"><div class="tile-label">%s</div><div class="tile-value">%s</div>'
            '<div class="tile-note">%s</div></div>' % (tone, E(label), value, note))


def pct(v):
    return "%+.2f%%" % v


def forecast_section(r):
    s, st, f = r["summary"], r["settings"], r["summary"]["final"]
    unit = kf.display_unit(r)
    n, h = st["paths"], st["horizon"]
    tiles = "".join([
        tile("最新收市價", "%s <small>%s</small>" % (kf.fmt(s["last_close"]), unit), E(s["last_date"])),
        tile("樂觀情況", kf.fmt(f["p90"]), pct(f["p90_change_pct"]), "up"),
        tile("中間情況", kf.fmt(f["median"]), pct(f["median_change_pct"]), "mid"),
        tile("悲觀情況", kf.fmt(f["p10"]), pct(f["p10_change_pct"]), "down"),
        tile("收市價較高的模擬", "%d <small>/ %d 次</small>" % (s["paths_above_last_close"], n),
             "並不代表上升機會率是 %.0f%%" % s["share_above_pct"]),
    ])
    rows = "".join("<tr><td>%s</td><td>%s</td><td><b>%s</b></td><td>%s</td></tr>"
                   % (E(x["date"]), kf.fmt(x["p10"]), kf.fmt(x["median"]), kf.fmt(x["p90"])) for x in s["steps"])
    return """
<section>
  <h2>一、未來 %d 個交易日的模擬結果</h2>
  <p class="lead">模型根據過去 %d 個交易日的股價，把未來 %d 個交易日的走勢模擬了 %d 次。
  以下為 %d 個交易日後（約 %s）的模擬收市價，括號內為與最新收市價比較的升跌幅。</p>
  <div class="tiles">%s</div>
  <figure class="chart-card">
    <figcaption><b>走勢模擬圖</b>（%s）<span class="hint">把滑鼠移到圖上可看每日數值</span></figcaption>
    <div class="legend">
      <span><i class="key line-hist"></i>過往收市價</span>
      <span><i class="key line-mid"></i>中間情況</span>
      <span><i class="key band"></i>悲觀至樂觀情況（約八成模擬結果）</span>
    </div>
    <div class="chart" id="fan"></div>
  </figure>
  <details class="table-view" open>
    <summary>未來每個交易日的模擬收市價（%s）</summary>
    <table><thead><tr><th>日期</th><th>悲觀情況</th><th>中間情況</th><th>樂觀情況</th></tr></thead>
    <tbody>%s</tbody></table>
  </details>
</section>""" % (h, st["lookback"], h, n, h, E(f["date"]), tiles, unit, unit, rows)


def backtest_section(b):
    s, st = b["score"], b["settings"]
    n, h = s["cases"], st["horizon"]
    band, middle, direction = kf.backtest_verdicts(s)
    lo, hi = s["inside_ci95"]
    tiles = "".join([
        tile("實際收市價落在範圍內", "%d <small>/ %d 次</small>" % (s["inside"], n),
             "即 %.0f%%；理想約為八成" % s["inside_pct"], "warn" if hi < 80 else ""),
        tile("中間情況平均誤差", "%.2f%%" % s["median_error_pct"],
             "「假設股價不變」為 %.2f%%" % s["no_change_error_pct"]),
        tile("升跌方向相同", "%d <small>/ %d 次</small>" % (s["direction_hits"], s["direction_called"]),
             "每次都估同一方向可對 %d 次" % max(s["actual_up"], n - s["actual_up"])),
    ])
    rows = []
    for c in b["cases"]:
        mark = ("▼ 低於範圍" if c["actual"] < c["p10"] else "▲ 高於範圍" if c["actual"] > c["p90"] else "● 在範圍內")
        rows.append("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"
                    % (E(c["origin_date"]), kf.fmt(c["last_close"]), kf.fmt(c["p10"]), kf.fmt(c["median"]),
                       kf.fmt(c["p90"]), kf.fmt(c["actual"]), mark))
    return """
<section>
  <h2>二、回測表現</h2>
  <p class="lead">回到過去 %d 個日子（%s 至 %s，每隔 %d 個交易日一次），每次只用當日或以前的股價模擬 %d 次，
  再與其後 %d 個交易日的實際收市價比較。這部分用來判斷上面的模擬範圍有多可靠。</p>
  <div class="tiles three">%s</div>
  <ul class="verdicts">
    <li><b>範圍：</b>%s</li>
    <li><b>中間情況：</b>%s</li>
    <li><b>升跌方向：</b>%s</li>
  </ul>
  <figure class="chart-card">
    <figcaption><b>每次回測：模擬範圍與實際結果</b>（相對起點收市價的升跌幅）<span class="hint">把滑鼠移到圖上可看詳情</span></figcaption>
    <div class="legend">
      <span><i class="key bar-k"></i>模型的悲觀至樂觀情況</span>
      <span><i class="key bar-b"></i>簡單範圍（按過去波動幅度計算）</span>
      <span><i class="key dot-in">●</i>實際收市價：在範圍內</span>
      <span><i class="key dot-out">▲▼</i>實際收市價：高於／低於範圍</span>
    </div>
    <div class="chart" id="bt"></div>
  </figure>
  <p class="note">簡單範圍：實際收市價落在其中 %d 次（%.0f%%）。模型範圍平均闊 %.2f%%，簡單範圍平均闊 %.2f%%；
  範圍越闊越容易涵蓋實際價格，兩者須一併比較。回測只有 %d 次，落在範圍內比例的 95%% 信賴區間約為 %.0f%%–%.0f%%。</p>
  <details class="table-view">
    <summary>每次回測結果（%s）</summary>
    <table><thead><tr><th>起點</th><th>當日收市價</th><th>悲觀情況</th><th>中間情況</th><th>樂觀情況</th>
    <th>%d 個交易日後實際</th><th>結果</th></tr></thead><tbody>%s</tbody></table>
  </details>
</section>""" % (n, E(b["cases"][0]["origin_date"]), E(b["cases"][-1]["origin_date"]), st["step"], st["paths"], h,
                 tiles, E(band), E(middle), E(direction), s["baseline_inside"], s["baseline_inside_pct"],
                 s["width_pct"], s["baseline_width_pct"], n, lo, hi, kf.display_unit(b), h, "".join(rows))


def notes_section(r, b):
    st = r["settings"]
    n = st["paths"]
    reminders = [
        "模型只參考過往股價及成交量，不會考慮業績、新聞、政策或停牌；期內如有重大事件，實際股價變動可遠超模擬範圍。",
        "「%d 次模擬中有 %d 次收市價較高」，並不代表股價上升的機會率是 %.0f%%。"
        % (n, r["summary"]["paths_above_last_close"], r["summary"]["share_above_pct"]),
        "本報告不應用作買賣決定，亦不應據此設定止蝕位或目標價。",
        "改變模擬日數、模擬次數或隨機設定編號，結果都會不同。",
    ]
    warnings = list(r["warnings"]) + ([w for w in b["warnings"] if w not in r["warnings"]] if b else [])
    warnings = [warning.replace("，屬 Kronos 已知現象", "") for warning in warnings]
    advanced = [
        "統計用詞對照：悲觀情況即第 10 百分位（P10），中間情況即中位數，樂觀情況即第 90 百分位（P90）。",
        "日線模型版本 %s，分詞器版本 %s" % (st["revision"][:7], st["tokenizer_revision"][:7]),
        "參考數據：過去 %d 個交易日（%s 至 %s），Yahoo Finance 日線"
        % (st["lookback"], r["data_source"]["history"]["start"], r["data_source"]["history"]["end"]),
        "隨機設定編號（seed）%d，每批 %d 次模擬；模型參數 T=%s、top_p=%s；運算裝置 %s"
        % (st["seed"], st.get("batch", 1), st["temperature"], st["top_p"], kf.device_name(st)),
    ]
    li = lambda items: "".join("<li>%s</li>" % E(x) for x in items)
    return """
<section class="notes">
  <h2>三、閱讀說明</h2>
  <div class="cols">
    <div><h3>名詞解釋</h3><ul>%s</ul></div>
    <div><h3>使用提醒</h3><ul>%s</ul><h3>資料限制</h3><ul>%s</ul></div>
  </div>
  <details><summary>進階資料</summary><ul>%s</ul></details>
</section>""" % (li(kf.glossary(n)), li(reminders), li(warnings), li(advanced))


CSS = """
:root{--brand:#131C47;--brand-2:#0C0380;--accent:#04D9DC;--surface:#ffffff;--page:#f4f5f8;--ink:#0b0b0b;
--ink-2:#52514e;--ink-3:#7a7974;--grid:#e6e6e3;--k:#2a78d6;--k-band:#b7d3f6;--k-bar:#9ec5f4;--b-bar:#e4e3df;
--out:#eb6834;--hist:#52514e}
*{box-sizing:border-box}body{margin:0;background:var(--page);color:var(--ink);
font-family:-apple-system,"PingFang HK","Noto Sans HK","Microsoft JhengHei",sans-serif;line-height:1.6}
header{background:var(--brand);color:#fff;padding:28px 0 24px}
.wrap{max-width:1040px;margin:0 auto;padding:0 24px}
.brandrow{display:flex;align-items:center;gap:14px;font-size:13px;opacity:.85}
.brandrow img{height:30px;background:#fff;border-radius:6px;padding:3px 6px}
h1{margin:12px 0 4px;font-size:30px;letter-spacing:.5px}h1 small{font-size:18px;font-weight:400;opacity:.8}
.sub{opacity:.85;font-size:15px}.badge{display:inline-block;margin-top:12px;border:1px solid var(--accent);color:var(--accent);
border-radius:999px;padding:2px 12px;font-size:13px}
section{background:var(--surface);border-radius:14px;padding:24px 28px;margin:20px 0;box-shadow:0 1px 2px rgba(0,0,0,.05)}
h2{margin:0 0 6px;font-size:21px;color:var(--brand)}h3{font-size:15px;margin:14px 0 4px;color:var(--brand)}
.lead{color:var(--ink-2);margin:0 0 16px}.note{color:var(--ink-2);font-size:14px}
.event{border-left:4px solid var(--accent);background:#effbfb;padding:12px 16px;border-radius:6px;font-size:14px;color:var(--ink-2)}
.tiles{display:grid;grid-template-columns:repeat(5,1fr);gap:10px}.tiles.three{grid-template-columns:repeat(3,1fr)}
.tile{border:1px solid var(--grid);border-radius:10px;padding:12px 14px}
.tile-label{font-size:13px;color:var(--ink-2)}.tile-value{font-size:24px;font-weight:700;font-variant-numeric:tabular-nums}
.tile-value small{font-size:13px;font-weight:400;color:var(--ink-2)}.tile-note{font-size:12.5px;color:var(--ink-3)}
.tile.mid{border-color:var(--k);box-shadow:inset 0 3px 0 var(--k)}.tile.warn{box-shadow:inset 0 3px 0 var(--out)}
.verdicts{margin:14px 0 0;padding-left:20px;color:var(--ink-2)}.verdicts li{margin:3px 0}
.chart-card{margin:18px 0 6px;border:1px solid var(--grid);border-radius:10px;padding:14px 16px}
figcaption{font-size:14px;color:var(--ink-2)}.hint{float:right;font-size:12px;color:var(--ink-3)}
.legend{display:flex;flex-wrap:wrap;gap:16px;font-size:13px;color:var(--ink-2);margin:8px 0 4px}
.key{display:inline-block;vertical-align:middle;margin-right:6px;font-style:normal}
.line-hist{width:18px;height:2px;background:var(--hist)}.line-mid{width:18px;height:2px;background:var(--k)}
.band{width:18px;height:10px;background:var(--k-band);border-radius:2px}
.bar-k{width:8px;height:14px;background:var(--k-bar);border-radius:4px}.bar-b{width:14px;height:14px;background:var(--b-bar);border-radius:4px}
.dot-in{color:var(--k);font-size:12px}.dot-out{color:var(--out);font-size:11px}
.chart{position:relative}.chart svg{display:block;width:100%;height:auto;overflow:visible}
.chart text{font-size:12px;fill:var(--ink-2);font-variant-numeric:tabular-nums}
.tip{position:absolute;pointer-events:none;background:#fff;border:1px solid var(--grid);border-radius:8px;
box-shadow:0 4px 14px rgba(0,0,0,.12);padding:8px 10px;font-size:12.5px;line-height:1.5;white-space:nowrap;display:none;z-index:2}
.tip b{color:var(--ink)}.tip .row{display:flex;justify-content:space-between;gap:14px;color:var(--ink-2)}
table{width:100%;border-collapse:collapse;font-size:13.5px;font-variant-numeric:tabular-nums;margin-top:8px}
th,td{padding:6px 8px;border-bottom:1px solid var(--grid);text-align:right}th:first-child,td:first-child{text-align:left}
td:last-child{text-align:right}th{color:var(--ink-2);font-weight:600}
details summary{cursor:pointer;color:var(--brand);font-weight:600;margin-top:12px}
.notes ul{padding-left:20px;margin:4px 0;color:var(--ink-2);font-size:14px}.cols{display:grid;grid-template-columns:1fr 1fr;gap:24px}
footer{font-size:12.5px;color:var(--ink-2);padding:4px 0 36px}.disclaimer{background:#fff7f2;border:1px solid #f6d3c1;
border-radius:10px;padding:14px 18px;margin:20px 0;font-size:13px;color:var(--ink-2)}
@media (max-width:760px){.tiles{grid-template-columns:repeat(2,1fr)}.tiles.three{grid-template-columns:1fr}.cols{grid-template-columns:1fr}
h1{font-size:24px}section{padding:18px}}
@media print{body{background:#fff}section{box-shadow:none;border:1px solid var(--grid);break-inside:avoid}details{display:block}}
"""

JS = r"""
const D = JSON.parse(document.getElementById('data').textContent);
const NS = 'http://www.w3.org/2000/svg';
const fmt = v => v.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
const sg = v => (v >= 0 ? '+' : '') + v.toFixed(2) + '%';
function el(tag, attrs, parent) { const e = document.createElementNS(NS, tag);
  for (const k in attrs) e.setAttribute(k, attrs[k]); if (parent) parent.appendChild(e); return e; }
function txt(parent, x, y, s, attrs) { const t = el('text', Object.assign({x, y}, attrs || {}), parent); t.textContent = s; return t; }
function niceTicks(lo, hi, n) { const step0 = (hi - lo) / n, mag = Math.pow(10, Math.floor(Math.log10(step0)));
  const step = [1, 2, 2.5, 5, 10].map(m => m * mag).find(s => s >= step0);
  const out = []; for (let v = Math.ceil(lo / step) * step; v <= hi + 1e-9; v += step) out.push(+v.toFixed(6)); return out; }
function tipper(box) { const t = document.createElement('div'); t.className = 'tip'; box.appendChild(t);
  return { show(html, px, py) { t.innerHTML = html; t.style.display = 'block';
      const w = t.offsetWidth, bw = box.clientWidth; t.style.left = Math.min(Math.max(px + 14, 0), bw - w) + 'px';
      t.style.top = Math.max(py - t.offsetHeight - 10, 0) + 'px'; }, hide() { t.style.display = 'none'; } }; }

function fan() {
  const box = document.getElementById('fan'), W = 960, H = 400, m = {l: 56, r: 118, t: 16, b: 34};
  const hist = D.history, steps = D.steps, n = hist.length + steps.length;
  const all = hist.map(d => d.close).concat(steps.flatMap(s => [s.p10, s.p90]));
  let lo = Math.min(...all), hi = Math.max(...all); const pad = (hi - lo) * 0.08; lo -= pad; hi += pad;
  const x = i => m.l + i / (n - 1) * (W - m.l - m.r), y = v => m.t + (hi - v) / (hi - lo) * (H - m.t - m.b);
  const svg = el('svg', {viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': '走勢模擬圖'}, box);
  niceTicks(lo, hi, 5).forEach(v => { el('line', {x1: m.l, x2: W - m.r, y1: y(v), y2: y(v), stroke: 'var(--grid)'}, svg);
    txt(svg, m.l - 8, y(v) + 4, fmt(v), {'text-anchor': 'end'}); });
  const L = hist.length - 1, last = hist[L].close;
  const up = [[x(L), y(last)]].concat(steps.map((s, j) => [x(L + 1 + j), y(s.p90)]));
  const dn = steps.map((s, j) => [x(L + 1 + j), y(s.p10)]).reverse().concat([[x(L), y(last)]]);
  el('polygon', {points: up.concat(dn).map(p => p.join(',')).join(' '), fill: 'var(--k-band)', opacity: .75}, svg);
  el('line', {x1: x(L), x2: x(L), y1: m.t, y2: H - m.b, stroke: 'var(--ink-3)', 'stroke-dasharray': '3 4'}, svg);
  txt(svg, x(L) + 6, m.t + 12, '最新收市', {fill: 'var(--ink-3)'});
  el('polyline', {points: hist.map((d, i) => [x(i), y(d.close)].join(',')).join(' '), fill: 'none', stroke: 'var(--hist)',
    'stroke-width': 2, 'stroke-linejoin': 'round'}, svg);
  el('polyline', {points: [[x(L), y(last)]].concat(steps.map((s, j) => [x(L + 1 + j), y(s.median)])).map(p => p.join(',')).join(' '),
    fill: 'none', stroke: 'var(--k)', 'stroke-width': 2.5, 'stroke-linejoin': 'round'}, svg);
  const f = steps[steps.length - 1], ex = x(n - 1);
  const labels = [[f.p90, '樂觀 ' + fmt(f.p90)], [f.median, '中間 ' + fmt(f.median)], [f.p10, '悲觀 ' + fmt(f.p10)]];
  let prev = -1e9; labels.forEach(([v, s]) => { const yy = Math.max(y(v), prev + 18); prev = yy;
    el('line', {x1: ex + 2, x2: ex + 10, y1: y(v), y2: yy, stroke: 'var(--ink-3)'}, svg);
    txt(svg, ex + 13, yy + 4, s, {fill: 'var(--ink)', 'font-weight': s.startsWith('中間') ? 700 : 400}); });
  [[0, hist[0].date, 'start'], [L, hist[L].date, 'middle'], [n - 1, f.date, 'end']].forEach(([i, s, a]) =>
    txt(svg, x(i), H - 10, s, {'text-anchor': a}));
  const cross = el('line', {y1: m.t, y2: H - m.b, stroke: 'var(--ink-3)', visibility: 'hidden'}, svg);
  const dot = el('circle', {r: 4.5, fill: 'var(--k)', stroke: '#fff', 'stroke-width': 2, visibility: 'hidden'}, svg);
  const tip = tipper(box), hit = el('rect', {x: m.l, y: m.t, width: W - m.l - m.r, height: H - m.t - m.b, fill: 'transparent'}, svg);
  hit.addEventListener('pointermove', ev => {
    const r = svg.getBoundingClientRect(), sx = (ev.clientX - r.left) / r.width * W;
    const i = Math.max(0, Math.min(n - 1, Math.round((sx - m.l) / (W - m.l - m.r) * (n - 1))));
    cross.setAttribute('x1', x(i)); cross.setAttribute('x2', x(i)); cross.setAttribute('visibility', 'visible');
    let html, v;
    if (i <= L) { v = hist[i].close; html = `<b>${hist[i].date}</b><div class="row"><span>收市價</span><b>${fmt(v)}</b></div>`; }
    else { const s = steps[i - L - 1]; v = s.median;
      html = `<b>${s.date}（模擬）</b><div class="row"><span>樂觀情況</span><span>${fmt(s.p90)}</span></div>` +
        `<div class="row"><span>中間情況</span><b>${fmt(s.median)}</b></div><div class="row"><span>悲觀情況</span><span>${fmt(s.p10)}</span></div>`; }
    dot.setAttribute('cx', x(i)); dot.setAttribute('cy', y(v)); dot.setAttribute('visibility', 'visible');
    dot.setAttribute('fill', i <= L ? 'var(--hist)' : 'var(--k)');
    tip.show(html, x(i) / W * r.width, y(v) / H * r.height); });
  hit.addEventListener('pointerleave', () => { tip.hide(); cross.setAttribute('visibility', 'hidden'); dot.setAttribute('visibility', 'hidden'); });
}

function backtest() {
  const box = document.getElementById('bt'); if (!box) return;
  const C = D.cases.map(c => { const p = v => (v / c.last_close - 1) * 100;
    return Object.assign({}, c, {k10: p(c.p10), k50: p(c.median), k90: p(c.p90), b10: p(c.baseline_low), b90: p(c.baseline_high), a: p(c.actual),
      state: c.actual < c.p10 ? 'below' : c.actual > c.p90 ? 'above' : 'in'}); });
  const W = 960, H = 340, m = {l: 52, r: 16, t: 14, b: 40}, n = C.length;
  const vals = C.flatMap(c => [c.k10, c.k90, c.b10, c.b90, c.a]);
  let lo = Math.min(...vals), hi = Math.max(...vals); const pad = (hi - lo) * 0.06; lo -= pad; hi += pad;
  const bw = (W - m.l - m.r) / n, x = i => m.l + bw * (i + .5), y = v => m.t + (hi - v) / (hi - lo) * (H - m.t - m.b);
  const svg = el('svg', {viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': '回測：模擬範圍與實際結果'}, box);
  niceTicks(lo, hi, 5).forEach(v => { el('line', {x1: m.l, x2: W - m.r, y1: y(v), y2: y(v), stroke: v === 0 ? 'var(--ink-3)' : 'var(--grid)'}, svg);
    txt(svg, m.l - 8, y(v) + 4, (v > 0 ? '+' : '') + v + '%', {'text-anchor': 'end'}); });
  const cols = [];
  C.forEach((c, i) => {
    const g = el('g', {}, svg); cols.push(g);
    el('rect', {x: x(i) - bw * .36, width: bw * .72, y: y(c.b90), height: Math.max(y(c.b10) - y(c.b90), 1), rx: 4, fill: 'var(--b-bar)'}, g);
    el('rect', {x: x(i) - bw * .17, width: bw * .34, y: y(c.k90), height: Math.max(y(c.k10) - y(c.k90), 1), rx: 4, fill: 'var(--k-bar)'}, g);
    el('line', {x1: x(i) - bw * .17, x2: x(i) + bw * .17, y1: y(c.k50), y2: y(c.k50), stroke: 'var(--k)', 'stroke-width': 2}, g);
    const ay = y(c.a), s = 6;
    if (c.state === 'in') el('circle', {cx: x(i), cy: ay, r: 4.5, fill: 'var(--k)', stroke: '#fff', 'stroke-width': 2}, g);
    else { const pts = c.state === 'above' ? [[0, -s], [s, s * .8], [-s, s * .8]] : [[0, s], [s, -s * .8], [-s, -s * .8]];
      el('polygon', {points: pts.map(([dx, dy]) => [x(i) + dx, ay + dy].join(',')).join(' '), fill: 'var(--out)', stroke: '#fff', 'stroke-width': 1.5}, g); }
    if (i % 5 === 0 || i === n - 1) txt(svg, x(i), H - 14, c.origin_date.slice(2).replace(/-/g, '/'), {'text-anchor': 'middle'});
  });
  txt(svg, m.l, H - 0, '起點日期', {fill: 'var(--ink-3)'});
  const tip = tipper(box), name = {in: '● 在範圍內', above: '▲ 高於範圍', below: '▼ 低於範圍'};
  const hit = el('rect', {x: m.l, y: m.t, width: W - m.l - m.r, height: H - m.t - m.b, fill: 'transparent'}, svg);
  hit.addEventListener('pointermove', ev => {
    const r = svg.getBoundingClientRect(), sx = (ev.clientX - r.left) / r.width * W;
    const i = Math.max(0, Math.min(n - 1, Math.floor((sx - m.l) / bw))), c = C[i];
    cols.forEach((g, j) => g.setAttribute('opacity', j === i ? 1 : .35));
    tip.show(`<b>起點 ${c.origin_date}</b>（收市 ${fmt(c.last_close)}）` +
      `<div class="row"><span>模型範圍</span><span>${fmt(c.p10)} – ${fmt(c.p90)}</span></div>` +
      `<div class="row"><span>中間情況</span><span>${fmt(c.median)}（${sg(c.k50)}）</span></div>` +
      `<div class="row"><span>${c.target_date} 實際</span><b>${fmt(c.actual)}（${sg(c.a)}）</b></div>` +
      `<div class="row"><span>結果</span><b>${name[c.state]}</b></div>`, x(i) / W * r.width, y(Math.max(c.k90, c.a)) / H * r.height); });
  hit.addEventListener('pointerleave', () => { tip.hide(); cols.forEach(g => g.setAttribute('opacity', 1)); });
}
fan(); backtest();
"""


def build(forecast, raw, backtest=None, events=None, logo=None):
    r = forecast
    if backtest and backtest["symbol"] != r["symbol"]:
        raise ValueError("回測代號 %s 與模擬代號 %s 不符。" % (backtest["symbol"], r["symbol"]))
    data = {"history": history(r, raw), "steps": r["summary"]["steps"], "cases": backtest["cases"] if backtest else []}
    st, f = r["settings"], r["summary"]["final"]
    logo_html = ('<img src="data:image/png;base64,%s" alt="投創教育">' % base64.b64encode(logo).decode()) if logo else ""
    event_html = ('<div class="event"><b>期內事件：</b>%s</div>' % E(events)) if events else (
        '<div class="event"><b>期內事件：</b>未有查核模擬期內是否有業績公布、除淨或其他重大事件。</div>')
    title = "%s（%s）AI 股市走勢模擬" % (r["symbol"], r["instrument_name"])
    page = """<!doctype html>
<html lang="zh-Hant-HK"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>%s</title><style>%s</style></head><body>
<header><div class="wrap">
  <div class="brandrow">%s<span>AI 走勢模擬報告 · 由 A.I. 生成 · 製作日期 %s</span></div>
  <h1>%s <small>%s</small></h1>
  <div class="sub">AI 股市走勢模擬：未來 %d 個交易日（至約 %s）· 最新收市價 %s %s（%s）</div>
  <span class="badge">僅屬模擬 · 並非預測 · 並非投資建議</span>
</div></header>
<main class="wrap">
%s
%s
%s
%s
<div class="disclaimer">%s</div>
</main>
<footer class="wrap">數據來源：Yahoo Finance（免費公開來源，可能有延遲或錯誤）。模型於本機運行。</footer>
<script type="application/json" id="data">%s</script>
<script>%s</script>
</body></html>
""" % (E(title), CSS, logo_html, dt.date.today().isoformat(), E(r["symbol"]), E(r["instrument_name"]), st["horizon"],
       E(f["date"]), kf.fmt(r["summary"]["last_close"]), kf.display_unit(r), E(r["summary"]["last_date"]),
       event_html, forecast_section(r), backtest_section(backtest) if backtest else "", notes_section(r, backtest),
       E(kf.DISCLAIMER_FULL), json.dumps(data, ensure_ascii=False).replace("</", "<\\/"), JS)
    return page


def main(argv=None):
    p = argparse.ArgumentParser(description="以 market_forecast.py 的輸出製作可分享的 HTML 報告")
    p.add_argument("--forecast", type=Path, required=True, help="模擬 JSON（market_forecast.py --json FILE）")
    p.add_argument("--raw", type=Path, required=True, help="同一次執行保存的 Yahoo 原始 JSON（--save-raw FILE）")
    p.add_argument("--backtest", type=Path, help="回測 JSON（market_forecast.py --backtest --json FILE）")
    p.add_argument("--events", help="期內事件說明（書面語）；不提供則註明未有查核")
    p.add_argument("--logo", type=Path, help="標誌 PNG（預設使用 skill 內的投創教育標誌）")
    p.add_argument("--no-logo", action="store_true", help="不加標誌")
    p.add_argument("-o", "--output", type=Path, required=True, help="HTML 儲存位置")
    p.add_argument("--overwrite", action="store_true", help="允許覆寫已存在的輸出檔")
    a = p.parse_args(argv)
    try:
        if a.output.exists() and not a.overwrite:
            raise ValueError("輸出檔已存在，請選新檔名，或在確認覆寫後加 --overwrite。")
        load = lambda path: json.loads(path.read_text(encoding="utf-8"))
        forecast = load(a.forecast)
        if forecast.get("mode", "forecast") != "forecast":
            raise ValueError("--forecast 必須是一般模擬的 JSON。")
        backtest = load(a.backtest) if a.backtest else None
        if backtest and backtest.get("mode") != "backtest":
            raise ValueError("--backtest 必須是回測的 JSON。")
        logo = None if a.no_logo else (a.logo or (DEFAULT_LOGO if DEFAULT_LOGO.is_file() else None))
        page = build(forecast, load(a.raw), backtest, a.events, logo.read_bytes() if logo else None)
        a.output.parent.mkdir(parents=True, exist_ok=True)
        a.output.write_text(page, encoding="utf-8")
    except (ValueError, KeyError, OSError) as error:
        print("走勢報告：" + str(error), file=sys.stderr)
        return 2
    print("HTML 報告：%s" % a.output.resolve())
    return 0


if __name__ == "__main__":
    sys.exit(main())
