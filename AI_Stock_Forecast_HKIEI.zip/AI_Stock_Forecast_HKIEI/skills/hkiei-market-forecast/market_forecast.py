#!/usr/bin/env python3
"""Daily-bar market outlook for the HKIEI plugin.

Fetches Yahoo Finance daily OHLCV, runs the open-source model
(NeoQuasar, MIT) on the CPU N times with fixed seeds, and summarises the
simulated paths. A simulation, not a prediction.

The top level uses the standard library only. The model needs PyTorch, which
setup_market_forecast.py installs once into a private environment; this script then
re-executes itself under that environment's Python.
"""
import argparse
import contextlib
import datetime as dt
import html
import json
import math
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
VERSION = "1.1.0"
RUNTIME_VERSION = 1
MODEL = {"repo": "NeoQuasar/Kronos-small", "revision": "901c26c1332695a2a8f243eb2f37243a37bea320"}
TOKENIZER = {"repo": "NeoQuasar/Kronos-Tokenizer-base", "revision": "0e0117387f39004a9016484a186a908917e22426"}
NOT_READY_EXIT = 3
DISCLAIMER = "僅供教育參考，並非預測或投資建議。數據可能有延遲。"
DISCLAIMER_FULL = (
    "⚠️ 免責聲明：本內容僅供教育及資訊參考，並不構成任何投資建議、要約或招攬買賣任何證券。"
    "這些模擬結果只是模型根據過往股價及成交量推算的可能走勢，並非預測，亦不保證準確。"
    "投資涉及風險，證券價格可升可跌，過往表現不代表將來表現。數據來自 Yahoo Finance 免費公開來源，"
    "可能有延遲或錯誤。投資者應自行判斷，如有需要請諮詢持牌專業人士。")


# ----------------------------------------------------------------- runtime

def runtime_home():
    custom = os.environ.get("HKIEI_FORECAST_HOME") or os.environ.get("KRONOS_FORECAST_HOME")
    if custom:
        return Path(custom).expanduser()
    cache = Path.home() / ".cache"
    current = cache / "hkiei-market-forecast"
    previous = cache / "kronos-forecast"
    if load_runtime(current) is None and load_runtime(previous) is not None:
        return previous
    return current


def venv_python(base):
    return base / "venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def _weights_ok(entry, spec):
    path = Path(entry.get("path", ""))
    return (entry.get("repo") == spec["repo"] and entry.get("revision") == spec["revision"]
            and (path / "config.json").is_file() and (path / "model.safetensors").is_file())


def load_runtime(base=None):
    """Return runtime.json when the environment and pinned weights are all in place, else None."""
    base = base or runtime_home()
    try:
        data = json.loads((base / "runtime.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if (not isinstance(data, dict) or data.get("runtime_version") != RUNTIME_VERSION
            or not Path(data.get("python", "")).is_file()
            or not _weights_ok(data.get("model") or {}, MODEL)
            or not _weights_ok(data.get("tokenizer") or {}, TOKENIZER)):
        return None
    return data


def not_ready_message():
    return ("走勢預測工具：尚未安裝模型運行環境。\n"
            "首次使用請在插件的技能資料夾執行 python3 setup_market_forecast.py。\n"
            "安裝會下載 PyTorch、模型及分詞器，需時約 3–5 分鐘。")


def ensure_runtime():
    """Return the runtime, re-executing this script under its Python when needed."""
    runtime = load_runtime()
    if runtime is None:
        print(not_ready_message(), file=sys.stderr)
        raise SystemExit(NOT_READY_EXIT)
    try:
        import torch  # noqa: F401
        import pandas  # noqa: F401
        return runtime
    except ImportError:
        pass
    if os.environ.get("HKIEI_FORECAST_REEXEC"):
        print("走勢預測工具：運行環境不完整，請重新執行 setup_market_forecast.py。", file=sys.stderr)
        raise SystemExit(NOT_READY_EXIT)
    os.environ["HKIEI_FORECAST_REEXEC"] = "1"
    python = runtime["python"]
    os.execv(python, [python, "-I", "-B", str(Path(__file__).resolve())] + sys.argv[1:])


# ----------------------------------------------------------------- data

def normalize_symbol(value):
    symbol = value.strip().upper()
    aliases = {"恒指": "^HSI", "HSI": "^HSI", "國企指數": "^HSCE",
               "納指": "^IXIC", "IXIC": "^IXIC", "標普": "^GSPC", "標普500": "^GSPC"}
    symbol = aliases.get(value.strip(), aliases.get(symbol, symbol))
    if not re.fullmatch(r"\^?[A-Z0-9][A-Z0-9.=-]{0,24}", symbol):
        raise ValueError("無效代號。例：NVDA、0700.HK、^HSI、BTC-USD。")
    if re.fullmatch(r"\d{1,5}\.HK", symbol):
        symbol = symbol[:-3].zfill(4) + ".HK"
    return symbol


def fetch_chart(symbol, timeout=20, years=2):
    url = ("https://query1.finance.yahoo.com/v8/finance/chart/" + urllib.parse.quote(symbol, safe="")
           + "?" + urllib.parse.urlencode({"range": "%dy" % years, "interval": "1d"}))
    request = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (compatible; MarketForecast/1.0; Python urllib)",
        "Accept": "application/json"})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                raw = response.read(20_000_001)
            if len(raw) > 20_000_000:
                raise ValueError("Yahoo 回應資料過大。")
            return json.loads(raw.decode("utf-8")), url
        except urllib.error.HTTPError as error:
            if error.code in (429, 500, 502, 503, 504) and attempt < 2:
                time.sleep(attempt + 1)
                continue
            raise ValueError("Yahoo HTTP %s，未能取得行情，請稍後再試。" % error.code)
        except (urllib.error.URLError, TimeoutError, OSError) as error:
            if attempt < 2:
                time.sleep(attempt + 1)
                continue
            raise ValueError("Yahoo 連線失敗：%s" % error)
    raise ValueError("Yahoo 連線失敗。")


def _num(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value) if math.isfinite(value) else None


def parse_chart(payload, now):
    from zoneinfo import ZoneInfo
    chart = payload.get("chart") or {}
    if chart.get("error"):
        raise ValueError("Yahoo API 錯誤：%s" % chart["error"].get("description", chart["error"]))
    results = chart.get("result") or []
    if not results:
        raise ValueError("Yahoo 沒有回傳行情。")
    result = results[0]
    meta = result.get("meta") or {}
    try:
        tz = ZoneInfo(meta.get("exchangeTimezoneName") or "UTC")
    except Exception:
        tz = dt.timezone(dt.timedelta(seconds=_num(meta.get("gmtoffset")) or 0))
    quote = ((result.get("indicators") or {}).get("quote") or [{}])[0]
    by_date, skipped = {}, 0
    for i, stamp in enumerate(result.get("timestamp") or []):
        if _num(stamp) is None or stamp > now + 300:
            skipped += 1
            continue
        bar = {}
        for key in ("open", "high", "low", "close", "volume"):
            series = quote.get(key) or []
            bar[key] = _num(series[i]) if i < len(series) else None
        prices = [bar[k] for k in ("open", "high", "low", "close")]
        if (any(p is None or p <= 0 for p in prices) or bar["low"] > min(bar["open"], bar["close"])
                or bar["high"] < max(bar["open"], bar["close"])):
            skipped += 1
            continue
        if bar["volume"] is None or bar["volume"] < 0:
            bar["volume"] = 0.0
        bar["date"] = dt.datetime.fromtimestamp(stamp, tz).date().isoformat()
        by_date[bar["date"]] = bar
    bars = [by_date[d] for d in sorted(by_date)]
    dropped = None
    if bars:
        today = dt.datetime.fromtimestamp(now, tz).date().isoformat()
        regular = (meta.get("currentTradingPeriod") or {}).get("regular") or {}
        end = _num(regular.get("end"))
        finished = (end is not None and dt.datetime.fromtimestamp(end, tz).date().isoformat() == today
                    and now >= end + 900)
        if bars[-1]["date"] == today and not finished:
            dropped = bars.pop()
    if len(bars) < 60:
        raise ValueError("已收市交易日少於 60 個，資料不足以運行模型。")
    return meta, str(tz), bars, skipped, dropped


def future_dates(last_date, count, weekends):
    out, day = [], dt.date.fromisoformat(last_date)
    while len(out) < count:
        day += dt.timedelta(days=1)
        if weekends or day.weekday() < 5:
            out.append(day)
    return out


# ----------------------------------------------------------------- model

def load_predictor(runtime, threads, device="auto"):
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
    sys.path.insert(0, str(HERE / "vendor"))
    import torch
    with contextlib.redirect_stdout(sys.stderr):
        from model import Kronos, KronosTokenizer, KronosPredictor
    torch.set_num_threads(threads)
    with contextlib.redirect_stdout(sys.stderr):
        tokenizer = KronosTokenizer.from_pretrained(runtime["tokenizer"]["path"])
        model = Kronos.from_pretrained(runtime["model"]["path"])
    tokenizer.eval()
    model.eval()
    mps = torch.backends.mps.is_available()
    if device == "mps" and not mps:
        raise ValueError("此電腦不支援 mps，請改用 --device cpu。")
    if device == "auto":
        device = "mps" if mps else "cpu"
    predictor = KronosPredictor(model, tokenizer, device=device, max_context=512)
    return predictor, {"torch": torch.__version__, "threads": threads, "device": device}


def batch_plan(jobs, paths, batch):
    """Split jobs x paths simulations into batches of (job index, path index) pairs."""
    flat = [(j, k) for j in range(jobs) for k in range(paths)]
    return [flat[i:i + batch] for i in range(0, len(flat), batch)]


def simulate(predictor, jobs, paths, temperature, top_p, seed, batch, progress=None):
    """Run `paths` simulations for every (bars, future dates) job, many sequences per model pass.

    Copies of the same history are stacked into one batch: the model samples each row independently,
    so one pass yields many simulations. sample_count stays 1 because the underlying model averages its samples.
    Batch number c is seeded with seed + c, so results depend on seed, paths and batch size.
    All jobs must share the same history length and horizon.
    """
    import numpy as np
    import pandas as pd
    import torch
    prepared = []
    for bars, future in jobs:
        frame = pd.DataFrame([{k: b[k] for k in ("open", "high", "low", "close", "volume")} for b in bars])
        x_time = pd.Series(pd.to_datetime([b["date"] for b in bars]))
        y_time = pd.Series(pd.to_datetime([d.isoformat() for d in future]))
        prepared.append((frame, x_time, y_time, [d.isoformat() for d in future]))
    results = [[] for _ in jobs]
    plan = batch_plan(len(jobs), paths, batch)
    for c, chunk in enumerate(plan):
        np.random.seed(seed + c)
        torch.manual_seed(seed + c)
        with torch.no_grad(), contextlib.redirect_stdout(sys.stderr):
            preds = predictor.predict_batch([prepared[j][0] for j, _ in chunk], [prepared[j][1] for j, _ in chunk],
                                            [prepared[j][2] for j, _ in chunk], pred_len=len(prepared[0][3]),
                                            T=temperature, top_p=top_p, sample_count=1, verbose=False)
        for (j, _), pred in zip(chunk, preds):
            dates = prepared[j][3]
            results[j].append([{"date": dates[i], **{k: float(row[k]) for k in ("open", "high", "low", "close", "volume")}}
                               for i, (_, row) in enumerate(pred.iterrows())])
        if progress:
            progress(c + 1, len(plan))
    return results


# ----------------------------------------------------------------- summary

def quantile(values, q):
    v = sorted(values)
    if not v:
        return None
    k = (len(v) - 1) * q
    lo, hi = math.floor(k), math.ceil(k)
    return v[lo] + (v[hi] - v[lo]) * (k - lo)


def summarise(bars, paths):
    last = bars[-1]["close"]
    steps = []
    for j in range(len(paths[0])):
        closes = [p[j]["close"] for p in paths]
        steps.append({"date": paths[0][j]["date"], "p10": quantile(closes, .1), "median": quantile(closes, .5),
                      "p90": quantile(closes, .9), "min": min(closes), "max": max(closes)})
    finals = [p[-1]["close"] for p in paths]
    # Closes only: the model can emit simulated bars whose high/low do not bracket open/close.
    highs = [max(b["close"] for b in p) for p in paths]
    lows = [min(b["close"] for b in p) for p in paths]
    invalid = 0
    for p in paths:
        if any(b["low"] > min(b["open"], b["close"]) or b["high"] < max(b["open"], b["close"])
               or min(b["open"], b["high"], b["low"], b["close"]) <= 0 for b in p):
            invalid += 1
    up = sum(1 for f in finals if f > last)
    pct = lambda v: (v / last - 1) * 100
    return {"last_close": last, "last_date": bars[-1]["date"], "steps": steps,
            "final": {"date": steps[-1]["date"], "median": quantile(finals, .5), "p10": quantile(finals, .1),
                      "p90": quantile(finals, .9), "min": min(finals), "max": max(finals),
                      "median_change_pct": pct(quantile(finals, .5)), "p10_change_pct": pct(quantile(finals, .1)),
                      "p90_change_pct": pct(quantile(finals, .9)), "min_change_pct": pct(min(finals)),
                      "max_change_pct": pct(max(finals))},
            "paths_above_last_close": up, "paths_total": len(paths), "share_above_pct": up / len(paths) * 100,
            "horizon_high_median": quantile(highs, .5), "horizon_low_median": quantile(lows, .5),
            "paths_with_inconsistent_ohlc": invalid}


def fmt(value):
    return "—" if value is None else "{:,.2f}".format(value)


CURRENCY_NAMES = {"USD": "美元", "HKD": "港元", "CNY": "人民幣", "JPY": "日圓", "EUR": "歐元",
                  "GBP": "英鎊", "TWD": "新台幣", "SGD": "新加坡元", "AUD": "澳元", "CAD": "加元"}


def display_unit(r):
    if r["unit"] == "index points":
        return "點"
    return CURRENCY_NAMES.get(r["unit"], r["unit"])


def device_name(settings):
    return "Apple 晶片 GPU（mps）" if settings.get("device") == "mps" else "CPU"


def glossary(n):
    tenth = max(1, round(n / 10))
    return [
        "模擬：模型根據過往股價及成交量，推算未來每日股價可能怎樣變動。由於每次推算的結果都會略有不同，"
        "所以重複模擬 %d 次，觀察結果大致落在甚麼範圍，好比擲骰子 %d 次，看看點數大多落在哪裏。這並非預測。" % (n, n),
        "中間情況：把 %d 次模擬的收市價由低至高排列，排在正中間的數值。" % n,
        "悲觀情況：只有約一成模擬結果（%d 次中約 %d 次）比此更低。" % (n, tenth),
        "樂觀情況：只有約一成模擬結果（%d 次中約 %d 次）比此更高。悲觀至樂觀情況之間，包含約八成模擬結果。" % (n, tenth),
        "交易日：股市開市的日子，不包括週末。",
        "收市價：每個交易日最後的成交價。",
    ]


def text_report(r):
    s, st = r["summary"], r["settings"]
    f = s["final"]
    unit = display_unit(r)
    n, h = st["paths"], st["horizon"]
    up = s["paths_above_last_close"]
    tenth = max(1, round(n / 10))
    lines = []
    if (r.get("data_source") or {}).get("input_file"):
        lines.append("⚠️ 離線重播已保存數據，並非即時行情。")
    lines += [
        "📍 %s（%s）AI 股市走勢模擬：未來 %d 個交易日" % (r["symbol"], r["instrument_name"], h),
        "最新收市價：%s %s（%s）" % (fmt(s["last_close"]), unit, s["last_date"]),
        "",
        "摘要：模型根據過去 %d 個交易日的股價，模擬了 %d 次未來 %d 個交易日的走勢。"
        "%d 個交易日後（%s）的模擬收市價如下（括號內為與最新收市價比較的升跌幅）："
        % (st["lookback"], n, h, h, f["date"]),
        "- 樂觀情況：%s %s（%+.2f%%）" % (fmt(f["p90"]), unit, f["p90_change_pct"]),
        "- 中間情況：%s %s（%+.2f%%）" % (fmt(f["median"]), unit, f["median_change_pct"]),
        "- 悲觀情況：%s %s（%+.2f%%）" % (fmt(f["p10"]), unit, f["p10_change_pct"]),
        "%d 次模擬中，有 %d 次的收市價高於最新收市價。" % (n, up),
        "",
        "📅 未來每個交易日的模擬收市價",
        "| 日期 | 悲觀情況 | 中間情況 | 樂觀情況 |",
        "|---|---:|---:|---:|",
    ]
    for step in s["steps"]:
        lines.append("| %s | %s | %s | %s |" % (step["date"], fmt(step["p10"]), fmt(step["median"]), fmt(step["p90"])))
    lines += ["", "📖 名詞解釋"] + ["- " + g for g in glossary(n)]
    lines += ["", "🧭 使用提醒",
              "- 模型只參考過往股價及成交量，不會考慮業績、新聞、政策或停牌；期內如有重大事件，實際股價變動可遠超模擬範圍。",
              "- 「%d 次模擬中有 %d 次收市價較高」，並不代表股價上升的機會率是 %.0f%%。" % (n, up, s["share_above_pct"]),
              "- 本 skill 的準確度未經驗證，不應用作買賣決定，亦不應據此設定止蝕位或目標價。",
              "- 改變模擬日數、模擬次數或隨機設定編號，結果都會不同。"]
    lines += ["", "📋 進階資料（供深入參考）",
              "- 統計用詞對照：悲觀情況即第 10 百分位（P10），中間情況即中位數，樂觀情況即第 90 百分位（P90）。"
              "%d 次模擬中，約 %d 次低於悲觀情況，約 %d 次高於樂觀情況。" % (n, tenth, tenth),
              "- %d 次模擬中，%d 個交易日後最高為 %s（%+.2f%%），最低為 %s（%+.2f%%）。"
              % (n, h, fmt(f["max"]), f["max_change_pct"], fmt(f["min"]), f["min_change_pct"]),
              "- 未來 %d 個交易日內，最高收市價的中間情況約為 %s，最低收市價的中間情況約為 %s。"
              % (h, fmt(s["horizon_high_median"]), fmt(s["horizon_low_median"])),
              "- 日線模型版本 %s，分詞器版本 %s" % (st["revision"][:7], st["tokenizer_revision"][:7]),
              "- 參考數據：過去 %d 個交易日（%s 至 %s）" % (st["lookback"], r["data_source"]["history"]["start"],
                                                       r["data_source"]["history"]["end"]),
              "- 隨機設定編號（seed）%d，每批 %d 次模擬，用以重現相同結果；模型參數 T=%s、top_p=%s"
              % (st["seed"], st.get("batch", 1), st["temperature"], st["top_p"]),
              "- 運算：本機 %s，PyTorch %s，用時 %.1f 秒" % (device_name(st), st.get("torch", "—"), r.get("elapsed_seconds", 0)),
              "- 每次模擬的完整數據載於 JSON 輸出（--json）。"]
    lines += ["", "⚠️ 資料限制"] + ["- " + w for w in r["warnings"]] + ["", DISCLAIMER_FULL]
    return "\n".join(lines)


# ----------------------------------------------------------------- backtest

Z90 = 1.2815515655446004  # standard normal 90th percentile, for the P10-P90 band of the baseline


def backtest_origins(n_bars, lookback, horizon, step, count):
    """Indices of the last known bar of each backtest (oldest first), newest `count` kept.

    Origin i uses bars[i - lookback + 1 : i + 1] as history and bars[i + 1 : i + 1 + horizon] as the answer.
    """
    newest = n_bars - 1 - horizon
    return sorted(range(newest, lookback - 2, -step)[:count])


def baseline_band(closes, horizon):
    """P10-P90 of a driftless random walk with the history's daily log-return volatility."""
    rets = [math.log(b / a) for a, b in zip(closes, closes[1:])]
    mean = sum(rets) / len(rets)
    sd = math.sqrt(sum((r - mean) ** 2 for r in rets) / (len(rets) - 1))
    spread = Z90 * sd * math.sqrt(horizon)
    return closes[-1] * math.exp(-spread), closes[-1] * math.exp(spread)


def wilson(k, n, z=1.959963984540054):
    """95% Wilson interval for k successes out of n, in percent."""
    if n == 0:
        return None, None
    p = k / n
    centre = (p + z * z / (2 * n)) / (1 + z * z / n)
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return (centre - half) * 100, (centre + half) * 100


def backtest_case(history, answer, paths):
    last, actual = history[-1]["close"], answer[-1]["close"]
    finals = [p[-1]["close"] for p in paths]
    lo, hi = baseline_band([b["close"] for b in history], len(answer))
    return {"origin_date": history[-1]["date"], "target_date": answer[-1]["date"], "last_close": last,
            "actual": actual, "p10": quantile(finals, .1), "median": quantile(finals, .5),
            "p90": quantile(finals, .9), "baseline_low": lo, "baseline_high": hi,
            "paths_above_last_close": sum(1 for f in finals if f > last)}


def score_backtest(cases):
    n = len(cases)
    mean = lambda values: sum(values) / len(values) if values else None
    inside = sum(1 for c in cases if c["p10"] <= c["actual"] <= c["p90"])
    base_inside = sum(1 for c in cases if c["baseline_low"] <= c["actual"] <= c["baseline_high"])
    sign = lambda v: (v > 0) - (v < 0)
    called = [c for c in cases if sign(c["median"] - c["last_close"]) and sign(c["actual"] - c["last_close"])]
    hits = sum(1 for c in called if sign(c["median"] - c["last_close"]) == sign(c["actual"] - c["last_close"]))
    up = sum(1 for c in cases if c["actual"] > c["last_close"])
    lo, hi = wilson(inside, n)
    return {"cases": n, "inside": inside, "inside_pct": inside / n * 100, "inside_ci95": [lo, hi],
            "below": sum(1 for c in cases if c["actual"] < c["p10"]),
            "above": sum(1 for c in cases if c["actual"] > c["p90"]),
            "width_pct": mean([(c["p90"] - c["p10"]) / c["last_close"] * 100 for c in cases]),
            "median_error_pct": mean([abs(c["median"] - c["actual"]) / c["last_close"] * 100 for c in cases]),
            "direction_called": len(called), "direction_hits": hits, "actual_up": up,
            "baseline_inside": base_inside, "baseline_inside_pct": base_inside / n * 100,
            "baseline_width_pct": mean([(c["baseline_high"] - c["baseline_low"]) / c["last_close"] * 100 for c in cases]),
            "no_change_error_pct": mean([abs(c["last_close"] - c["actual"]) / c["last_close"] * 100 for c in cases])}


def backtest_verdicts(s):
    """Plain-language readings of the scores, in the order the report prints them."""
    lo, hi = s["inside_ci95"]
    if lo <= 80 <= hi:
        band = "與理想的八成相差不大。"
    elif hi < 80:
        band = "明顯少於八成，表示模擬範圍偏窄，低估了股價的實際波動。"
    else:
        band = "明顯多於八成，表示模擬範圍偏闊，參考價值有限。"
    gap = s["median_error_pct"] - s["no_change_error_pct"]
    if abs(gap) < 0.1:
        middle = "兩者相若，模型的中間情況並未比「假設股價不變」更接近實際收市價。"
    elif gap < 0:
        middle = "模型的中間情況平均較為接近實際收市價。"
    else:
        middle = "模型的中間情況反而不及「假設股價不變」接近實際收市價。"
    best_guess = max(s["actual_up"], s["cases"] - s["actual_up"])
    if s["direction_hits"] > best_guess:
        direction = "高於每次都估同一方向所能做到的 %d 次。" % best_guess
    else:
        direction = "並未高於每次都估同一方向所能做到的 %d 次，即升跌方向的判斷並無優勢。" % best_guess
    return band, middle, direction


def text_backtest(r):
    s, st = r["score"], r["settings"]
    unit = display_unit(r)
    n, h = s["cases"], st["horizon"]
    band, middle, direction = backtest_verdicts(s)
    lo, hi = s["inside_ci95"]
    cases = r["cases"]
    lines = []
    if (r.get("data_source") or {}).get("input_file"):
        lines.append("⚠️ 離線重播已保存數據，並非即時行情。")
    lines += [
        "📍 %s（%s）走勢模型回測：過去 %d 次，每次 %d 個交易日" % (r["symbol"], r["instrument_name"], n, h),
        "回測的做法：假設回到過去某一日，只用當日或以前的股價運行模型，再與其後 %d 個交易日的實際收市價比較，"
        "檢查模擬範圍是否可靠。本次回測的起點由 %s 至 %s，每隔 %d 個交易日一次，每次模擬 %d 次。"
        % (h, cases[0]["origin_date"], cases[-1]["origin_date"], st["step"], st["paths"]),
        "",
        "摘要：",
        "- 實際收市價落在悲觀至樂觀情況之間：%d 次中有 %d 次（%.0f%%）。理想約為八成；%s" % (n, s["inside"], s["inside_pct"], band),
        "- 實際收市價低於悲觀情況 %d 次，高於樂觀情況 %d 次。" % (s["below"], s["above"]),
        "- 中間情況與實際收市價平均相差 %.2f%%；如簡單假設「股價不變」，平均相差 %.2f%%。%s"
        % (s["median_error_pct"], s["no_change_error_pct"], middle),
        "- 中間情況的升跌方向與實際相同：%d 次中有 %d 次，%s" % (s["direction_called"], s["direction_hits"], direction),
        "- 對照：按過去股價波動幅度計算的簡單範圍，實際收市價落在其中 %d 次（%.0f%%）。"
        "模型範圍平均闊 %.2f%%，簡單範圍平均闊 %.2f%%；範圍越闊越容易涵蓋實際價格，兩者須一併比較。"
        % (s["baseline_inside"], s["baseline_inside_pct"], s["width_pct"], s["baseline_width_pct"]),
        "",
        "📅 每次回測結果（%s）" % unit,
        "| 起點 | 當日收市價 | 悲觀情況 | 中間情況 | 樂觀情況 | %d 個交易日後實際收市價 | 結果 |" % h,
        "|---|---:|---:|---:|---:|---:|---|",
    ]
    for c in cases:
        mark = "低於範圍" if c["actual"] < c["p10"] else "高於範圍" if c["actual"] > c["p90"] else "在範圍內"
        lines.append("| %s | %s | %s | %s | %s | %s | %s |" % (c["origin_date"], fmt(c["last_close"]), fmt(c["p10"]),
                                                            fmt(c["median"]), fmt(c["p90"]), fmt(c["actual"]), mark))
    lines += ["", "🧭 使用提醒",
              "- 回測只反映過去 %d 次的表現，次數不多，結果本身亦有誤差；過去表現不代表將來表現。" % n,
              "- 回測結果理想，並不代表可以根據 模型的模擬作買賣決定。",
              "- 回測使用實際交易日的收市價，因此不受公眾假期影響。"]
    if st["step"] < h:
        lines.append("- 各次回測的期間互相重疊，結果並非完全獨立，實際誤差可能比上述數字更大。")
    lines += ["", "📋 進階資料（供深入參考）",
              "- 統計用詞對照：悲觀情況即第 10 百分位（P10），中間情況即中位數，樂觀情況即第 90 百分位（P90）。",
              "- 落在範圍內比例的 95%% 信賴區間（Wilson）：%.0f%%–%.0f%%。" % (lo, hi),
              "- 簡單範圍：以參考期內每日對數回報的標準差 σ 計算，最新收市價 × exp(±1.2816 × σ × √%d)，"
              "即假設沒有趨勢的隨機漫步的 P10 至 P90。" % h,
              "- 日線模型版本 %s，分詞器版本 %s" % (st["revision"][:7], st["tokenizer_revision"][:7]),
              "- 每次回測參考過去 %d 個交易日；隨機設定編號（seed）%d，每批 %d 次模擬；模型參數 T=%s、top_p=%s"
              % (st["lookback"], st["seed"], st["batch"], st["temperature"], st["top_p"]),
              "- 運算：本機 %s，PyTorch %s，用時 %.1f 秒" % (device_name(st), st.get("torch", "—"), r.get("elapsed_seconds", 0))]
    lines += ["", "⚠️ 資料限制"] + ["- " + w for w in r["warnings"]] + ["", DISCLAIMER_FULL]
    return "\n".join(lines)


# ----------------------------------------------------------------- chart

def render_svg(r, bars, paths, size, chart_days):
    width, height = map(int, size.split("x"))
    portrait = height > width
    s = r["summary"]
    hist = bars[-chart_days:]
    steps = s["steps"]
    slots = len(hist) + len(steps)
    values = [b[k] for b in hist for k in ("high", "low")] + [x[k] for x in steps for k in ("p10", "p90")]
    lo, hi = min(values), max(values)
    pad = (hi - lo) * 0.08 or hi * 0.02
    lo, hi = lo - pad, hi + pad
    left, right = 90, width - (250 if portrait else 290)
    top, bottom = (300, 1260) if portrait else (205, 700)

    def x(i):
        return left + (i + 0.5) * (right - left) / slots

    def y(v):
        return bottom - (v - lo) / (hi - lo) * (bottom - top)

    esc = lambda v: html.escape(str(v), quote=True)
    el = ['<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d" role="img">' % (width, height, width, height),
          "<title>%s Market outlook simulation</title>" % esc(r["symbol"]),
          "<desc>Model-simulated paths on Yahoo daily OHLC. Simulation, not a prediction.</desc>",
          '<rect width="100%" height="100%" fill="#101b2b"/>',
          '<g font-family="PingFang TC, Noto Sans TC, Arial, sans-serif" fill="#e8eef5">']

    def text(tx, ty, value, fs=24, fill="#e8eef5", weight="400", anchor="start"):
        el.append('<text x="%.1f" y="%.1f" font-size="%s" fill="%s" font-weight="%s" text-anchor="%s">%s</text>'
                  % (tx, ty, fs, fill, weight, anchor, esc(value)))

    def line(x1, y1, x2, y2, color, w=1.0, dash="", opacity=1.0):
        el.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="%s" opacity="%s"%s/>'
                  % (x1, y1, x2, y2, color, w, opacity, (' stroke-dasharray="%s"' % dash) if dash else ""))

    st = r["settings"]
    unit = display_unit(r)
    rows_y = (80, 130, 172, 214) if portrait else (58, 98, 134, 170)
    text(left, rows_y[0], "%s  |  AI 走勢 %d 日模擬" % (r["symbol"], st["horizon"]), 46 if portrait else 40, weight="700")
    text(left, rows_y[1], "最新收市價 %s %s（%s）" % (fmt(s["last_close"]), unit, s["last_date"]), 28 if portrait else 26)
    text(left, rows_y[2], "本機模型 · 模擬 %d 次 · 隨機設定編號 %d" % (st["paths"], st["seed"]), 24 if portrait else 22, "#aabbcf")
    banner = ("OFFLINE SNAPSHOT · 非即時行情" if (r.get("data_source") or {}).get("input_file")
              else "AI 模擬範圍 · 並非預測 · 未計業績及新聞")
    text(left, rows_y[3], banner, 24 if portrait else 22, "#e7c36d")
    for i in range(6):
        v = lo + (hi - lo) * i / 5
        line(left, y(v), right, y(v), "#273950")
        text(12, y(v) + 6, fmt(v), 18, "#9cacc0")
    step = (right - left) / slots
    for i, b in enumerate(hist):
        color = "#56d8ad" if b["close"] >= b["open"] else "#f5838a"
        cx = x(i)
        line(cx, y(b["low"]), cx, y(b["high"]), color, 1.4)
        el.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="%s"/>'
                  % (cx - step * 0.32, y(max(b["open"], b["close"])), max(1, step * 0.64),
                     max(1, abs(y(b["open"]) - y(b["close"]))), color))
    start = len(hist) - 1
    line(x(start) + step / 2, top, x(start) + step / 2, bottom, "#5a6f8a", 1, "6 6")
    upper = [(x(start), y(s["last_close"]))] + [(x(start + 1 + j), y(st_["p90"])) for j, st_ in enumerate(steps)]
    lower = [(x(start + 1 + j), y(st_["p10"])) for j, st_ in enumerate(steps)][::-1] + [(x(start), y(s["last_close"]))]
    el.append('<polygon points="%s" fill="#7aa7ff" opacity="0.18"/>' % " ".join("%.1f,%.1f" % p for p in upper + lower))
    for p in paths[:8]:
        pts = [(x(start), y(s["last_close"]))] + [(x(start + 1 + j), y(b["close"])) for j, b in enumerate(p)]
        el.append('<polyline points="%s" fill="none" stroke="#9fb9e6" stroke-width="1" opacity="0.35"/>'
                  % " ".join("%.1f,%.1f" % q for q in pts))
    med = [(x(start), y(s["last_close"]))] + [(x(start + 1 + j), y(st_["median"])) for j, st_ in enumerate(steps)]
    el.append('<polyline points="%s" fill="none" stroke="#f5da88" stroke-width="3"/>' % " ".join("%.1f,%.1f" % q for q in med))
    f = s["final"]
    labels = sorted([(y(f["p90"]), "樂觀 %s" % fmt(f["p90"]), "#7aa7ff"),
                     (y(f["median"]), "中間 %s" % fmt(f["median"]), "#f5da88"),
                     (y(f["p10"]), "悲觀 %s" % fmt(f["p10"]), "#7aa7ff")])
    pos = []
    for actual, _, _ in labels:
        pos.append(max(actual, pos[-1] + 32 if pos else top + 10))
    for (actual, label, color), py in zip(labels, pos):
        line(right, actual, right + 20, py, color, 1)
        text(right + 26, py + 7, label, 22, color)
    text(left, bottom + 34, hist[0]["date"], 19, "#9cacc0")
    if right - x(start) > 200:  # skip the middle date when it would collide with the end date
        text(x(start), bottom + 34, s["last_date"], 19, "#9cacc0", anchor="middle")
    text(right, bottom + 34, f["date"], 19, "#9cacc0", anchor="end")
    text(left, bottom + (74 if portrait else 68), "藍色範圍：約八成模擬結果所在範圍　黃線：中間情況　淡線：部分模擬走勢",
         20, "#aabbcf")
    base = bottom + (150 if portrait else 125)
    gap = 46 if portrait else 40
    rows = [("%d 個交易日後（%s）中間情況：%s（%+.2f%%）" % (st["horizon"], f["date"], fmt(f["median"]), f["median_change_pct"]), "#f5da88"),
            ("悲觀至樂觀情況：%s 至 %s" % (fmt(f["p10"]), fmt(f["p90"])), "#e8eef5"),
            ("%d 次模擬中 %d 次收市價高於最新收市價（並非機會率）" % (s["paths_total"], s["paths_above_last_close"]), "#e8eef5")]
    for i, (value, color) in enumerate(rows):
        text(left, base + i * gap, value, 28 if portrait else 26, color, "700" if i == 0 else "400")
    foot = height - (120 if portrait else 70)
    text(left, foot, "模型只參考過往股價及成交量，不知悉業績、新聞及政策；結果屬模擬，並非預測。", 22, "#aabbcf")
    text(left, foot + 36, DISCLAIMER, 22, "#aabbcf")
    el += ["</g>", "</svg>"]
    return "\n".join(el)


# ----------------------------------------------------------------- main

def parser():
    p = argparse.ArgumentParser(description="AI 股市走勢模擬（並非預測，亦非投資建議）")
    p.add_argument("symbol", help="NVDA / 0700.HK / ^HSI / BTC-USD")
    p.add_argument("--days", type=int, default=10, help="模擬未來多少個交易日（1–30）")
    p.add_argument("--paths", type=int, help="模擬次數（5–200；預設 50，回測預設 20）")
    p.add_argument("--lookback", type=int, default=120, help="輸入模型的交易日數（60–500，預設 120；回測顯示 400 日表現較差）")
    p.add_argument("--temperature", type=float, default=1.0, help="模型參數 T（0.05–2，進階用）")
    p.add_argument("--top-p", type=float, default=0.9, help="模型參數 top_p（0.05–1，進階用）")
    p.add_argument("--seed", type=int, default=1729, help="隨機設定編號（seed），用以重現相同結果")
    p.add_argument("--threads", type=int, default=4, help="CPU 執行緒數目（1–16）")
    p.add_argument("--batch", type=int, default=25, help="每批同時運算的模擬次數（1–200）")
    p.add_argument("--device", choices=["auto", "cpu", "mps"], default="auto",
                   help="運算裝置：auto（預設，有 Apple 晶片 GPU 便用 mps）、cpu 或 mps；cpu 與 mps 結果略有不同")
    p.add_argument("--backtest", action="store_true", help="回測：在過去多個日子運行模型，與實際收市價比較")
    p.add_argument("--origins", type=int, default=30, help="回測次數（5–100）")
    p.add_argument("--step", type=int, help="回測每隔多少個交易日一次（1–60，預設等於 --days）")
    p.add_argument("--size", choices=["1920x1080", "1080x1920"], default="1920x1080")
    p.add_argument("--chart-days", type=int, help="圖中顯示的歷史交易日數（預設橫度 60、直度 30）")
    p.add_argument("--svg", type=Path, help="SVG 儲存位置（回測不輸出圖）")
    p.add_argument("--json", nargs="?", const="-", metavar="PATH", help="輸出 JSON 至 stdout，或寫入 PATH")
    p.add_argument("--input-json", type=Path, help="離線重播已保存的 Yahoo 原始 JSON（並非即時行情）")
    p.add_argument("--save-raw", type=Path, help="保存所用的 Yahoo 原始 JSON 以便重現")
    p.add_argument("--overwrite", action="store_true", help="允許覆寫已存在的輸出檔")
    return p


def validate(a):
    if a.paths is None:
        a.paths = 20 if a.backtest else 50
    if a.step is None:
        a.step = a.days
    checks = [(1 <= a.days <= 30, "--days 必須為 1–30。"), (5 <= a.paths <= 200, "--paths 必須為 5–200。"),
              (60 <= a.lookback <= 500, "--lookback 必須為 60–500。"),
              (0.05 <= a.temperature <= 2.0, "--temperature 必須為 0.05–2。"),
              (0.05 <= a.top_p <= 1.0, "--top-p 必須為 0.05–1。"),
              (1 <= a.threads <= 16, "--threads 必須為 1–16。"), (1 <= a.batch <= 200, "--batch 必須為 1–200。"),
              (5 <= a.origins <= 100, "--origins 必須為 5–100。"), (1 <= a.step <= 60, "--step 必須為 1–60。")]
    if a.backtest and a.svg:
        checks.append((False, "回測不輸出 SVG，請改用 --json。"))
    if a.chart_days is None:
        a.chart_days = 30 if a.size == "1080x1920" else 60
    checks.append((20 <= a.chart_days <= 200, "--chart-days 必須為 20–200。"))
    for ok, message in checks:
        if not ok:
            raise ValueError(message)


def check_targets(args, targets):
    resolved = [p.resolve() for p in targets]
    protected = {p.resolve() for p in HERE.rglob("*") if p.is_file()}
    if args.input_json:
        protected.add(args.input_json.resolve())
    if len(set(resolved)) != len(resolved) or any(p in protected for p in resolved):
        raise ValueError("輸出檔案位置不可重複，亦不可覆寫輸入檔或 skill 檔案。")
    if not args.overwrite and any(p.exists() for p in targets):
        raise ValueError("輸出檔已存在，請選新檔名，或在確認覆寫後加 --overwrite。")


def load_bars(args, symbol, years):
    url = None
    if args.input_json:
        payload = json.loads(args.input_json.read_text(encoding="utf-8"))
    else:
        payload, url = fetch_chart(symbol, years=years)
    meta, tz, bars, skipped, dropped = parse_chart(payload, time.time())
    returned = meta.get("symbol")
    if returned and normalize_symbol(returned) != symbol:
        raise ValueError("回應代號 %s 與要求 %s 不符。" % (returned, symbol))
    return payload, url, meta, tz, bars, skipped, dropped


def common_warnings(symbol, skipped, dropped, args):
    warnings = []
    if dropped:
        warnings.append("已剔除尚未收市的當日數據（%s）。" % dropped["date"])
    if skipped:
        warnings.append("已略過 %d 筆無效 Yahoo 紀錄。" % skipped)
    if symbol.startswith("^"):
        warnings.append("指數沒有真實成交量，Yahoo 提供的成交量只屬參考數值或為零。")
    if args.input_json:
        warnings.append("離線重播：行情來自已保存的檔案，不代表最新市況。")
    return warnings


def model_settings(args, lookback, info):
    return {"model": "small", "revision": MODEL["revision"], "tokenizer_revision": TOKENIZER["revision"],
            "horizon": args.days, "paths": args.paths, "seed": args.seed, "batch": args.batch,
            "temperature": args.temperature, "top_p": args.top_p, "lookback": lookback, "device": args.device, **info}


def emit(args, report, text, payload):
    if args.save_raw:
        args.save_raw.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    encoded = json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)
    if args.json == "-":
        print(encoded)
        return
    if args.json:
        Path(args.json).write_text(encoded, encoding="utf-8")
    print(text)


def run_backtest(args, symbol, runtime):
    started = time.time()
    targets = ([Path(args.json)] if args.json and args.json != "-" else []) + ([args.save_raw] if args.save_raw else [])
    check_targets(args, targets)
    payload, url, meta, tz, bars, skipped, dropped = load_bars(args, symbol, years=5)
    origins = backtest_origins(len(bars), args.lookback, args.days, args.step, args.origins)
    if len(origins) < 5:
        raise ValueError("歷史數據只有 %d 個交易日，不足以按參考 %d 日、模擬 %d 日做至少 5 次回測；可減少 --lookback。"
                         % (len(bars), args.lookback, args.days))
    jobs = [(bars[i - args.lookback + 1:i + 1], [dt.date.fromisoformat(b["date"]) for b in bars[i + 1:i + 1 + args.days]])
            for i in origins]
    predictor, info = load_predictor(runtime, args.threads, args.device)
    say = lambda done, total: print("走勢預測工具：回測進度 %d/%d 批" % (done, total), file=sys.stderr, flush=True)
    results = simulate(predictor, jobs, args.paths, args.temperature, args.top_p, args.seed, args.batch, say)
    cases = [backtest_case(history, bars[i + 1:i + 1 + args.days], paths)
             for i, (history, _), paths in zip(origins, jobs, results)]
    warnings = ["悲觀至樂觀情況只按每次 %d 次模擬計算，模擬次數較少時，範圍本身亦有誤差。" % args.paths]
    warnings += common_warnings(symbol, skipped, dropped, args)
    unit = "index points" if symbol.startswith("^") else meta.get("currency", "unknown")
    report = {"schema_version": VERSION, "mode": "backtest", "symbol": symbol,
              "instrument_name": meta.get("shortName") or meta.get("longName") or symbol, "unit": unit, "timezone": tz,
              "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
              "data_source": {"provider": "Yahoo Finance chart API", "url": url,
                              "input_file": str(args.input_json) if args.input_json else None,
                              "history": {"bars": len(bars), "start": bars[0]["date"], "end": bars[-1]["date"]}},
              "settings": dict(model_settings(args, args.lookback, info), step=args.step, origins=len(origins)),
              "score": score_backtest(cases), "cases": cases, "warnings": warnings, "disclaimer": DISCLAIMER,
              "elapsed_seconds": round(time.time() - started, 1)}
    emit(args, report, text_backtest(report), payload)
    return 0


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        validate(args)
        symbol = normalize_symbol(args.symbol)
    except ValueError as error:
        print("走勢預測工具：" + str(error), file=sys.stderr)
        return 2
    runtime = ensure_runtime()
    try:
        if args.backtest:
            return run_backtest(args, symbol, runtime)
        started = time.time()
        payload, url, meta, tz, bars, skipped, dropped = load_bars(args, symbol, years=2)
        used = bars[-args.lookback:]
        crypto = (meta.get("instrumentType") or "").upper() == "CRYPTOCURRENCY"
        future = future_dates(used[-1]["date"], args.days, weekends=crypto)
        stamp = used[-1]["date"]
        output = args.svg or Path("market_outlook_%s_%s_%s.svg" % (symbol.replace("^", "index_"), stamp, args.size))
        check_targets(args, [output] + ([Path(args.json)] if args.json and args.json != "-" else [])
                      + ([args.save_raw] if args.save_raw else []))
        predictor, info = load_predictor(runtime, args.threads, args.device)
        paths = simulate(predictor, [(used, future)], args.paths, args.temperature, args.top_p, args.seed, args.batch)[0]
        summary = summarise(used, paths)
        warnings = [
            "每次模擬均使用固定的隨機設定，以便重現結果；悲觀至樂觀情況只反映這 %d 次模擬的分佈，並非機會率保證。" % args.paths,
            "加密貨幣按每日連續計算，包括週末。" if crypto else
            "未來交易日只略過週末，未扣除公眾假期；日期或與實際交易日相差一至兩日。",
        ]
        if summary["paths_with_inconsistent_ohlc"]:
            warnings.append("%d/%d 次模擬出現不合理的每日價格（例如最高價低於收市價），因此統計只採用收市價。"
                            % (summary["paths_with_inconsistent_ohlc"], args.paths))
        warnings += common_warnings(symbol, skipped, dropped, args)
        unit = "index points" if symbol.startswith("^") else meta.get("currency", "unknown")
        report = {"schema_version": VERSION, "mode": "forecast", "symbol": symbol,
                  "instrument_name": meta.get("shortName") or meta.get("longName") or symbol,
                  "unit": unit, "timezone": tz, "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
                  "data_source": {"provider": "Yahoo Finance chart API", "url": url,
                                  "input_file": str(args.input_json) if args.input_json else None,
                                  "history": {"bars_used": len(used), "start": used[0]["date"], "end": used[-1]["date"]}},
                  "settings": model_settings(args, len(used), info),
                  "summary": summary, "paths": paths, "warnings": warnings, "disclaimer": DISCLAIMER,
                  "elapsed_seconds": round(time.time() - started, 1)}
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(render_svg(report, used, paths, args.size, args.chart_days), encoding="utf-8")
        report["svg_path"] = str(output.resolve())
        emit(args, report, text_report(report) + "\n\nSVG: %s" % report["svg_path"], payload)
        return 0
    except (ValueError, KeyError, IndexError, TypeError, OSError) as error:
        print("走勢預測工具：" + str(error), file=sys.stderr)
        return 2

if __name__ == "__main__":
    sys.exit(main())
