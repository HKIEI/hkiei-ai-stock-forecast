#!/usr/bin/env python3
"""One-time setup for the HKIEI market outlook plugin. Standard library only.

Creates a private Python environment with PyTorch and the required packages,
then downloads the pinned model and tokenizer from
Hugging Face. Everything lives in one folder (default ~/.cache/hkiei-market-forecast,
or $HKIEI_FORECAST_HOME), so deleting that folder removes it all.

  python3 setup_market_forecast.py            install, or repair an incomplete install
  python3 setup_market_forecast.py --check    report whether it is ready (exit 0 ready, 3 not)
  python3 setup_market_forecast.py --remove   delete the folder
"""
import argparse
import datetime as dt
import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import market_forecast as kf  # noqa: E402  (standard library only at import time)

PACKAGES = ["torch>=2.2", "numpy>=1.24", "pandas>=1.5", "einops>=0.6",
            "huggingface_hub>=0.20", "safetensors>=0.4", "tqdm>=4.60"]

DOWNLOAD = r"""
import json, sys
from huggingface_hub import snapshot_download
spec = json.loads(sys.argv[1])
out = {}
for key in ("model", "tokenizer"):
    item = spec[key]
    out[key] = snapshot_download(repo_id=item["repo"], revision=item["revision"], cache_dir=spec["cache"],
                                 allow_patterns=["config.json", "model.safetensors"])
print(json.dumps(out))
"""

VERIFY = r"""
import contextlib, json, sys
spec = json.loads(sys.argv[1])
sys.path.insert(0, spec["vendor"])
import einops, huggingface_hub, numpy, pandas, safetensors, torch
with contextlib.redirect_stdout(sys.stderr):
    from model import Kronos, KronosTokenizer
    KronosTokenizer.from_pretrained(spec["tokenizer"])
    Kronos.from_pretrained(spec["model"])
print(json.dumps({"python": sys.version.split()[0], "torch": torch.__version__, "numpy": numpy.__version__,
                  "pandas": pandas.__version__, "einops": einops.__version__,
                  "huggingface_hub": huggingface_hub.__version__, "safetensors": safetensors.__version__}))
"""


def say(message):
    print(message, file=sys.stderr, flush=True)


def platform_problem(version=None, system=None, machine=None):
    version = version or sys.version_info[:2]
    system = system or sys.platform
    machine = machine or platform.machine()
    if tuple(version) < (3, 9):
        return "需要 Python 3.9 或以上（現為 %d.%d）。" % tuple(version)
    if system == "darwin" and machine != "arm64":
        return ("此電腦為 Intel Mac（或以 Rosetta 執行 Python）。PyTorch 新版本已停止支援 Intel Mac，"
                "本 skill 只支援 Apple Silicon（M1 或以後）的 Mac。")
    return None


def folder_size(path):
    total = 0
    for root, _, files in os.walk(path):
        for name in files:
            try:
                total += os.lstat(os.path.join(root, name)).st_size
            except OSError:
                pass
    return total


def run(cmd, env=None):
    subprocess.run([str(c) for c in cmd], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, env=env)


def output(cmd, env=None):
    done = subprocess.run([str(c) for c in cmd], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, text=True)
    return json.loads(done.stdout.strip().splitlines()[-1])


def check(base):
    runtime = kf.load_runtime(base)
    if runtime:
        print("模型運行環境已就緒（%.0f MB）" % (folder_size(base) / 1e6))
        print("Python %s，PyTorch %s，模型版本 %s" % (runtime["packages"]["python"], runtime["packages"]["torch"],
                                              runtime["model"]["revision"][:7]))
        return 0
    print("模型運行環境尚未安裝或不完整。")
    print("請在插件的技能資料夾執行 python3 setup_market_forecast.py。")
    return kf.NOT_READY_EXIT


def remove(base):
    if not base.exists():
        print("沒有需要移除的運行環境。")
        return 0
    # Only ever delete a folder this script made: nothing in it but our own entries.
    entries = {p.name for p in base.iterdir()} - {".DS_Store"}
    if not entries <= {"runtime.json", "venv", "hf"} or base == Path.home() or len(base.parts) < 3:
        print("運行環境資料夾含其他檔案，已取消移除。", file=sys.stderr)
        return 2
    size = folder_size(base)
    shutil.rmtree(base)
    print("已刪除運行環境（%.0f MB）。" % (size / 1e6))
    return 0


def setup(base):
    problem = platform_problem()
    if problem:
        say("走勢預測工具：" + problem)
        return 2
    if sys.platform != "darwin":
        say("注意：本 skill 只在 Apple Silicon Mac 測試過，其他系統未經測試。")
    base.mkdir(parents=True, exist_ok=True)
    python = kf.venv_python(base)
    env = dict(os.environ, HF_HUB_DISABLE_TELEMETRY="1", PIP_DISABLE_PIP_VERSION_CHECK="1")
    env.pop("HF_HUB_OFFLINE", None)
    env.pop("PYTHONPATH", None)
    try:
        if not python.exists():
            say("1/4 建立獨立 Python 環境")
            run([sys.executable, "-m", "venv", base / "venv"], env)
        else:
            say("1/4 沿用已有的 Python 環境")
        say("2/4 安裝 PyTorch 及相關套件（首次約需數分鐘）")
        run([python, "-m", "pip", "install", "--upgrade", "pip"], env)
        run([python, "-m", "pip", "install"] + PACKAGES, env)
        say("3/4 從 Hugging Face 下載模型及分詞器")
        spec = {"cache": str(base / "hf"), "model": kf.MODEL, "tokenizer": kf.TOKENIZER}
        paths = output([python, "-I", "-c", DOWNLOAD, json.dumps(spec)], env)
        say("4/4 測試載入模型")
        versions = output([python, "-I", "-c", VERIFY, json.dumps(
            {"vendor": str(HERE / "vendor"), "model": paths["model"], "tokenizer": paths["tokenizer"]})],
            dict(env, HF_HUB_OFFLINE="1"))
    except subprocess.CalledProcessError as error:
        say("走勢預測工具：安裝失敗（退出碼 %d）。請檢查網絡及 Python 環境後重試。" % error.returncode)
        return 2
    runtime = {"runtime_version": kf.RUNTIME_VERSION, "python": str(python),
               "model": dict(kf.MODEL, path=paths["model"]), "tokenizer": dict(kf.TOKENIZER, path=paths["tokenizer"]),
               "packages": versions, "created": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")}
    (base / "runtime.json").write_text(json.dumps(runtime, ensure_ascii=False, indent=2), encoding="utf-8")
    if not kf.load_runtime(base):
        say("走勢預測工具：安裝後檢查失敗，請再執行一次。")
        return 2
    print("安裝完成（%.0f MB）" % (folder_size(base) / 1e6))
    print("Python %s，PyTorch %s，模型版本 %s" % (versions["python"], versions["torch"], kf.MODEL["revision"][:7]))
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(description="AI 股市走勢預測一次性安裝（PyTorch 及日線模型）")
    group = p.add_mutually_exclusive_group()
    group.add_argument("--check", action="store_true", help="只檢查是否已安裝")
    group.add_argument("--remove", action="store_true", help="刪除整個運行環境資料夾")
    args = p.parse_args(argv)
    base = kf.runtime_home()
    if args.check:
        return check(base)
    if args.remove:
        return remove(base)
    return setup(base)


if __name__ == "__main__":
    sys.exit(main())
