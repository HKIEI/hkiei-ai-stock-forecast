"""Offline tests for the non-model parts (no torch, no network). Synthetic data only."""
import contextlib
import datetime as dt
import io
import json
import math
import os
import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path
from unittest import mock

import market_forecast as kf
import market_report as kr
import setup_market_forecast as sk

COLLOQUIAL = "嘅唔喺冇係咗啲嚟佢呢噉咁嗰攞搵俾睇碰"


def payload(count=120, symbol="TSLA"):
    start = dt.datetime(2024, 1, 2, 14, 30, tzinfo=dt.timezone.utc)
    stamps, day = [], start
    while len(stamps) < count:
        if day.weekday() < 5:
            stamps.append(int(day.timestamp()))
        day += dt.timedelta(days=1)
    q = {k: [] for k in ("open", "high", "low", "close", "volume")}
    for i in range(count):
        close = 100 + 5 * math.sin(i / 7)
        op = close - 0.5
        for k, v in (("open", op), ("high", close + 1), ("low", op - 1), ("close", close), ("volume", 1000 + i)):
            q[k].append(v)
    meta = {"symbol": symbol, "exchangeTimezoneName": "America/New_York", "currency": "USD"}
    return {"chart": {"error": None, "result": [{"meta": meta, "timestamp": stamps, "indicators": {"quote": [q]}}]}}


def fake_paths(last, n=10, steps=5):
    out = []
    for i in range(n):
        path = []
        for j in range(steps):
            close = last + (i - n / 2) * 0.5 + j * 0.1
            path.append({"date": "2024-07-%02d" % (j + 1), "open": last, "high": max(last, close) + 1,
                         "low": min(last, close) - 1, "close": close, "volume": 1.0})
        out.append(path)
    return out


def fake_report(symbol="TSLA", unit="USD"):
    bars = kf.parse_chart(payload(), now=2_000_000_000)[2]
    paths = fake_paths(bars[-1]["close"])
    report = {"symbol": symbol, "instrument_name": "SYNTHETIC", "unit": unit, "summary": kf.summarise(bars, paths),
              "settings": {"model": "small", "repo": kf.MODEL["repo"], "revision": kf.MODEL["revision"],
                           "tokenizer_repo": kf.TOKENIZER["repo"], "tokenizer_revision": kf.TOKENIZER["revision"],
                           "paths": 10, "seed": 1, "horizon": 5, "temperature": 1.0, "top_p": 0.9,
                           "lookback": len(bars), "torch": "test"},
              "data_source": {"input_file": None, "history": {"start": bars[0]["date"], "end": bars[-1]["date"]}},
              "warnings": ["測試警告。"], "elapsed_seconds": 1.0}
    return report, bars, paths


def make_runtime(base, revision=None):
    python = base / "venv" / "bin" / "python"
    python.parent.mkdir(parents=True)
    python.write_text("")
    entries = {}
    for key, spec in (("model", kf.MODEL), ("tokenizer", kf.TOKENIZER)):
        folder = base / "hf" / key
        folder.mkdir(parents=True)
        (folder / "config.json").write_text("{}")
        (folder / "model.safetensors").write_text("")
        entries[key] = dict(spec, path=str(folder))
    if revision:
        entries["model"]["revision"] = revision
    (base / "runtime.json").write_text(json.dumps({"runtime_version": kf.RUNTIME_VERSION, "python": str(python),
                                                   "packages": {"python": "3.9", "torch": "x"}, **entries}))


class Data(unittest.TestCase):
    def test_symbols(self):
        for raw, want in [("700.hk", "0700.HK"), ("恒指", "^HSI"), ("nvda", "NVDA"), ("BTC-USD", "BTC-USD")]:
            self.assertEqual(kf.normalize_symbol(raw), want)
        with self.assertRaises(ValueError):
            kf.normalize_symbol("NV;DA")

    def test_parse_and_skip_bad(self):
        p = payload()
        q = p["chart"]["result"][0]["indicators"]["quote"][0]
        q["close"][3] = None
        q["low"][5] = 999
        meta, tz, bars, skipped, dropped = kf.parse_chart(p, now=2_000_000_000)
        self.assertEqual(skipped, 2)
        self.assertEqual(len(bars), 118)
        self.assertIsNone(dropped)

    def test_too_short(self):
        with self.assertRaises(ValueError):
            kf.parse_chart(payload(30), now=2_000_000_000)

    def test_future_dates(self):
        days = kf.future_dates("2026-11-06", 3, weekends=False)  # Friday
        self.assertEqual([d.isoformat() for d in days], ["2026-11-09", "2026-11-10", "2026-11-11"])
        self.assertEqual(len(kf.future_dates("2026-11-06", 3, weekends=True)), 3)

    def test_summary(self):
        report, _, _ = fake_report()
        s = report["summary"]
        self.assertLessEqual(s["final"]["p10"], s["final"]["median"])
        self.assertLessEqual(s["final"]["median"], s["final"]["p90"])
        self.assertEqual(s["paths_total"], 10)
        self.assertEqual(s["paths_with_inconsistent_ohlc"], 0)


class Output(unittest.TestCase):
    def test_svg_both_sizes(self):
        report, bars, paths = fake_report(symbol="A<&>")
        for size, days in (("1920x1080", 60), ("1080x1920", 30)):
            svg = kf.render_svg(report, bars, paths, size, days)
            root = ET.fromstring(svg)
            self.assertEqual(root.attrib["width"] + "x" + root.attrib["height"], size)
            self.assertIn("A&lt;&amp;&gt;", svg)

    def test_written_chinese_and_disclaimer(self):
        for symbol, unit in (("TSLA", "USD"), ("^HSI", "index points")):
            report, bars, paths = fake_report(symbol, unit)
            text = kf.text_report(report)
            svg = kf.render_svg(report, bars, paths, "1080x1920", 30)
            for content in (text, svg):
                self.assertEqual([c for c in COLLOQUIAL if c in content], [])
                self.assertNotIn("K 線", content)
            self.assertIn("免責聲明", text)
            self.assertIn("並不代表股價上升的機會率", text)
            self.assertIn(kf.DISCLAIMER, svg)
        self.assertIn(" 點（", kf.text_report(fake_report("^HSI", "index points")[0]))
        self.assertIn(" 美元（", kf.text_report(fake_report()[0]))

    def test_plain_words_outside_advanced_section(self):
        # Beginners misread P10/P90 as "10 / 90 days"; statistics words stay in the advanced section only.
        jargon = ["P10", "P90", "中位數", "路徑", "抽樣", "情景", "隨機種子", "機率", "USD", "index points"]
        report, bars, paths = fake_report()
        main = kf.text_report(report).split("📋 進階資料")[0]
        svg = kf.render_svg(report, bars, paths, "1920x1080", 60)
        body = svg.split("</desc>", 1)[1]
        for word in jargon:
            self.assertNotIn(word, main, word)
            self.assertNotIn(word, body, word)
        for case in ("樂觀情況", "中間情況", "悲觀情況"):
            self.assertIn(case, main)
        self.assertIn("P10", kf.text_report(report).split("📋 進階資料")[1])


class Runtime(unittest.TestCase):
    def test_load_runtime(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            self.assertIsNone(kf.load_runtime(base))
            make_runtime(base)
            self.assertIsNotNone(kf.load_runtime(base))
        with tempfile.TemporaryDirectory() as td:
            make_runtime(Path(td), revision="0" * 40)
            self.assertIsNone(kf.load_runtime(Path(td)))

    def test_not_ready_exit_code_and_message(self):
        with tempfile.TemporaryDirectory() as td, mock.patch.dict(os.environ, {"HKIEI_FORECAST_HOME": td}):
            err = io.StringIO()
            with contextlib.redirect_stderr(err), self.assertRaises(SystemExit) as caught:
                kf.ensure_runtime()
            self.assertEqual(caught.exception.code, kf.NOT_READY_EXIT)
            self.assertIn("setup_market_forecast.py", err.getvalue())

    def test_platform_problem(self):
        self.assertIsNotNone(sk.platform_problem((3, 8), "darwin", "arm64"))
        self.assertIsNotNone(sk.platform_problem((3, 11), "darwin", "x86_64"))
        self.assertIsNone(sk.platform_problem((3, 9), "darwin", "arm64"))
        self.assertIsNone(sk.platform_problem((3, 12), "linux", "x86_64"))

    def test_remove_only_own_folder(self):
        with tempfile.TemporaryDirectory() as td:
            other = Path(td) / "hkiei-market-forecast"
            other.mkdir()
            (other / "my-notes.txt").write_text("keep")
            with contextlib.redirect_stderr(io.StringIO()):
                self.assertEqual(sk.remove(other), 2)
            self.assertTrue((other / "my-notes.txt").exists())
            own = Path(td) / "own" / "hkiei-market-forecast"
            own.mkdir(parents=True)
            make_runtime(own)
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(sk.remove(own), 0)
            self.assertFalse(own.exists())


def fake_case(last, actual, p10, median, p90, lo=None, hi=None):
    return {"origin_date": "2026-01-02", "target_date": "2026-01-16", "last_close": last, "actual": actual,
            "p10": p10, "median": median, "p90": p90, "baseline_low": lo or last * 0.9,
            "baseline_high": hi or last * 1.1, "paths_above_last_close": 0}


def fake_backtest(cases):
    s = {"repo": kf.MODEL["repo"], "revision": kf.MODEL["revision"], "tokenizer_repo": kf.TOKENIZER["repo"],
         "tokenizer_revision": kf.TOKENIZER["revision"], "horizon": 10, "paths": 20, "seed": 1, "batch": 25,
         "temperature": 1.0, "top_p": 0.9, "lookback": 120, "step": 10, "device": "cpu", "torch": "test"}
    return {"symbol": "TSLA", "instrument_name": "SYNTHETIC", "unit": "USD", "settings": s, "cases": cases,
            "score": kf.score_backtest(cases), "data_source": {"input_file": None}, "warnings": ["測試警告。"],
            "elapsed_seconds": 1.0}


class Batching(unittest.TestCase):
    def test_plan_covers_every_simulation_once(self):
        plan = kf.batch_plan(jobs=3, paths=7, batch=5)
        flat = [pair for chunk in plan for pair in chunk]
        self.assertEqual(sorted(flat), [(j, k) for j in range(3) for k in range(7)])
        self.assertTrue(all(len(chunk) <= 5 for chunk in plan))
        self.assertEqual(len(plan), 5)


class Backtest(unittest.TestCase):
    def test_origins(self):
        origins = kf.backtest_origins(n_bars=200, lookback=120, horizon=10, step=10, count=100)
        self.assertEqual(origins[-1], 189)              # newest origin leaves exactly 10 answer bars
        self.assertGreaterEqual(origins[0], 119)        # oldest origin still has a full history window
        self.assertEqual(origins, sorted(origins))
        self.assertEqual(len(kf.backtest_origins(200, 120, 10, 10, 3)), 3)
        self.assertEqual(kf.backtest_origins(100, 120, 10, 10, 30), [])

    def test_baseline_band_is_symmetric_in_log_space(self):
        closes = [100 * (1.01 if i % 2 else 0.99) ** i for i in range(60)]
        lo, hi = kf.baseline_band(closes, 10)
        self.assertAlmostEqual(math.log(hi / closes[-1]), -math.log(lo / closes[-1]))
        self.assertLess(lo, closes[-1])
        flat_lo, flat_hi = kf.baseline_band([100.0] * 30 + [100.0001], 10)
        self.assertLess(flat_hi - flat_lo, 0.01)

    def test_case_uses_last_answer_bar(self):
        history = [{"date": "2026-01-%02d" % (i + 1), "close": 100.0 + (i % 3)} for i in range(20)]
        answer = [{"date": "2026-02-%02d" % (i + 1), "close": 110.0 + i} for i in range(5)]
        paths = [[{"close": 100.0 + k}] * 5 for k in range(10)]
        c = kf.backtest_case(history, answer, paths)
        self.assertEqual(c["actual"], 114.0)
        self.assertEqual(c["last_close"], history[-1]["close"])
        self.assertEqual(c["target_date"], "2026-02-05")
        self.assertAlmostEqual(c["median"], 104.5)

    def test_score(self):
        cases = [fake_case(100, 101, 95, 102, 105),   # inside, direction right
                 fake_case(100, 90, 95, 102, 105),    # below, direction wrong
                 fake_case(100, 110, 95, 98, 105),    # above, direction wrong
                 fake_case(100, 100, 95, 100, 105)]   # inside, no direction called
        s = kf.score_backtest(cases)
        self.assertEqual((s["inside"], s["below"], s["above"]), (2, 1, 1))
        self.assertEqual((s["direction_called"], s["direction_hits"], s["actual_up"]), (3, 1, 2))
        self.assertAlmostEqual(s["width_pct"], 10.0)
        self.assertAlmostEqual(s["no_change_error_pct"], (1 + 10 + 10 + 0) / 4)
        lo, hi = s["inside_ci95"]
        self.assertTrue(lo < 50 < hi)

    def test_wilson(self):
        lo, hi = kf.wilson(24, 30)
        self.assertTrue(lo < 80 < hi)
        lo, hi = kf.wilson(7, 30)
        self.assertLess(hi, 80)
        self.assertEqual(kf.wilson(0, 0), (None, None))

    def test_verdicts(self):
        good = [fake_case(100, 100 + (i % 5), 95, 100 + (i % 5), 105) for i in range(25)]
        good += [fake_case(100, 120, 95, 100, 105) for _ in range(5)]
        band, middle, _ = kf.backtest_verdicts(kf.score_backtest(good))
        self.assertIn("相差不大", band)
        self.assertIn("較為接近", middle)
        narrow = [fake_case(100, 120, 99, 80, 101) for _ in range(30)]
        band, middle, direction = kf.backtest_verdicts(kf.score_backtest(narrow))
        self.assertIn("偏窄", band)
        self.assertIn("不及", middle)
        self.assertIn("並無優勢", direction)

    def test_report_is_written_chinese(self):
        cases = [fake_case(100, 100 + i, 95, 101, 105) for i in range(10)]
        text = kf.text_backtest(fake_backtest(cases))
        self.assertEqual([c for c in COLLOQUIAL if c in text], [])
        main = text.split("📋 進階資料")[0]
        for word in ["P10", "P90", "中位數", "路徑", "抽樣", "機率", "概率", "USD"]:
            self.assertNotIn(word, main, word)
        self.assertIn("免責聲明", text)
        self.assertIn("美元", text)
        self.assertEqual(text.count("| 2026-01-02 |"), 10)

    def test_cli_rules(self):
        for argv in (["NVDA", "--backtest", "--svg", "x.svg"], ["NVDA", "--paths", "201"], ["NVDA", "--batch", "0"],
                     ["NVDA", "--backtest", "--origins", "4"]):
            with self.subTest(argv=argv), self.assertRaises(ValueError):
                kf.validate(kf.parser().parse_args(argv))
        a = kf.parser().parse_args(["NVDA", "--backtest", "--days", "5"])
        kf.validate(a)
        self.assertEqual((a.paths, a.step, a.lookback), (20, 5, 120))
        a = kf.parser().parse_args(["NVDA"])
        kf.validate(a)
        self.assertEqual((a.paths, a.device), (50, "auto"))


class Report(unittest.TestCase):
    def forecast(self):
        report, bars, _ = fake_report()
        report.update({"mode": "forecast", "generated_utc": "2033-05-18T00:00:00+00:00", "timezone": "America/New_York"})
        report["data_source"]["history"]["end"] = bars[-1]["date"]
        report["settings"]["batch"] = 25
        return report

    def test_html_report(self):
        cases = [fake_case(100, 100 + i, 95, 101, 105) for i in range(10)]
        bt = dict(fake_backtest(cases), mode="backtest")
        page = kr.build(self.forecast(), payload(), bt, events="期內沒有已知事件。", logo=b"PNG")
        self.assertEqual([c for c in COLLOQUIAL if c in page], [])
        for text in ("免責聲明", "期內沒有已知事件。", "回測", "名詞解釋", "data:image/png;base64,"):
            self.assertIn(text, page)
        data = json.loads(page.split('id="data">', 1)[1].split("</script>", 1)[0])
        self.assertEqual(len(data["history"]), kr.HISTORY_DAYS)
        self.assertEqual(len(data["cases"]), 10)

    def test_html_report_without_backtest_or_events(self):
        page = kr.build(self.forecast(), payload())
        self.assertIn("未有查核", page)
        self.assertNotIn("二、回測", page)

    def test_mismatched_raw_rejected(self):
        r = self.forecast()
        r["data_source"]["history"]["end"] = "1999-01-01"
        with self.assertRaises(ValueError):
            kr.build(r, payload())

    def test_bundled_logo(self):
        self.assertTrue(kr.DEFAULT_LOGO.is_file())


if __name__ == "__main__":
    unittest.main()
